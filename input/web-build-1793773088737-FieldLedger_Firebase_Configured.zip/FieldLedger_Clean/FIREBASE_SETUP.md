# FieldLedger 2.0 — Firebase setup (Engineer-only)

This package includes Firebase Email/Password sign-in, Firestore visit sync, offline local storage with automatic retry on reconnect, and Firebase Storage receipt upload. Android package ID is aligned with the supplied Firebase Android registration (`com.saikat.bdt`). It uses Firebase's Web SDK inside the Android WebView. Android WebView assets are served through WebViewAssetLoader so HTTPS module imports work.

## 1. Create Firebase project
1. Open https://console.firebase.google.com/ and create a project.
2. The supplied Android app registration is `com.saikat.bdt`; this project package now matches it. The Android `google-services.json` is included.
3. The app currently uses the Firebase Web SDK inside its WebView for email/password authentication, Firestore, and Storage. The config file has been prefilled from the supplied project values. If Firebase rejects the app identifier or web SDK configuration, register a Firebase Web app and replace `firebase-config.js` with its Web config. Never put service-account JSON or private keys in the app.
4. In Authentication > Sign-in method, enable **Email/Password**.
5. In Authentication > Users, create your engineer account (or use Create account in the app). Use a strong password.

## 2. Enable database and receipt storage
1. Build > Firestore Database > Create database. Choose production mode and a region close to your users (for Bangladesh, choose an available Asia region).
2. Open Firestore Rules and paste `firebase/firestore.rules`, then Publish.
3. Build > Storage > Get started. Create the default bucket.
4. Open Storage Rules and paste `firebase/storage.rules`, then Publish.
5. Review Firebase billing/usage and set budget alerts. Storage may require a billing-enabled plan depending on current Firebase policy and bucket configuration.

## 3. Build APK
1. Zip the `FieldLedger_Clean` folder contents (the folder itself may be at the ZIP root).
2. Upload ZIP to AndroidForge, select Android APK and debug, then Build.
3. Install the APK and sign in with the engineer account.

## Data behavior / limitations
- Visit records and expenses are stored locally first; they are synchronized to `users/{uid}/visits` when online. Firestore offline persistence is enabled where supported; the app also retains its local copy and retries on reconnect.
- Receipt images are retained locally while offline and uploaded to Firebase Storage during the next online sync. Verify Storage rules and test an image upload before relying on remote backups.
- Each engineer account can read/write only its own `/users/{uid}/...` path. This is an engineer-only personal workspace, not an office review workflow.
- The app's existing office-review screens remain visible as local prototype screens; there is no separate office account or remote approval workflow in this engineer-only edition.
- The Firebase web config is a client identifier, not a secret. Security comes from Authentication and the published Firestore/Storage rules. Never upload service-account keys or share passwords.
- Test with a sample visit and receipt first. Confirm the Cloud: synced indicator, then sign in on a second install using the same account to verify data retrieval.
