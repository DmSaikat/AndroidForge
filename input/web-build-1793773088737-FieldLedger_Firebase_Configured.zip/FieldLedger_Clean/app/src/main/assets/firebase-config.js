// Populated from the Firebase Android app configuration supplied by the project owner.
// Client configuration is not a service-account secret. Secure access with Firebase rules.
export const firebaseConfig = {
  apiKey: "AIzaSyAcpRqCzZxx9s3WiBmglQErSAqJ7KcJiY0",
  authDomain: "fieldvisit-268f9.firebaseapp.com",
  projectId: "fieldvisit-268f9",
  storageBucket: "fieldvisit-268f9.firebasestorage.app",
  messagingSenderId: "318592094699",
  appId: "1:318592094699:android:460da7f5111bd5222209ae"
};
