# v1.9.7 Code Review

Scope: expose the three already-approved company BYA/NYY chart images directly inside Measurement Tools → Cable & Breaker Reference.

Checks performed:
- All three image files exist in web and Android WebView asset folders.
- Both `index.html` copies are byte-identical.
- Chart previews use relative local asset paths and do not require network access.
- Full-screen viewer supports close button, outside tap, and Escape key.
- Service-worker cache key incremented and charts added to offline precache list.
- No PWD reference source is introduced into electrical calculation logic.

Android compilation and on-device display have not been run in this environment.
