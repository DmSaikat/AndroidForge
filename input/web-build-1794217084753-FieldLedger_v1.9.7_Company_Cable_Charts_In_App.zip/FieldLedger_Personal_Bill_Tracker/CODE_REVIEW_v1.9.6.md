# FieldLedger v1.9.6 — source review and validation

## Data separation
- Electrical sizing screens (`Load & Breaker Calculator` and `Cable & Breaker Reference`) use only user-supplied company BYA/NYY chart data.
- PWD SoR 2022 cable ampacity data is not present in the electrical-calculation lookup or functions. PWD rates and reference material remain in the BOQ & Tender workspace.

## Company data represented
- BYA in conduit/trunking: source-published current ranges. The lower end is used for preliminary capacity checks.
- NYY in air/cable tray and NYY direct buried in ground: source-published current ratings.
- BYA and NYY single-core, plain annealed copper, PVC-insulated, non-sheathed, 35°C clipped-to-surface chart: base current, 30% / 25% / 20% safety current and ECC size.
- Company SP / DP / TP breaker selection chart. SP and TP values are loaded as printed; DP cells remain unavailable. NYY TP `100/125` remains a text range, not silently converted to a single rating.

## Safety-margin handling
The source's 4.5 mm² and 14.5 mm² BYA 30% / 25% figures do not match base × (1 − margin). The app retains the printed source figure but uses the lower of the printed value and the arithmetic derating for calculations. This avoids overstating available capacity. The 20% column used by the company breaker chart matches the associated breaker chart values.

## Calculation notes
- Company quick-table BYA ranges use the lower end before safety margin.
- The selected safety margin is applied once; correction factors for ambient, grouping and thermal/installation are applied afterwards.
- Cable breaker-chart recommendations are shown separately from the generic IB ≤ In ≤ IZ screen. If a company chart rating exceeds corrected Iz, the screen warns rather than treating it as compliant.
- Voltage-drop calculation is an indicative copper-resistivity estimate; cable reactance, actual operating temperature, connections and project-specific limits require separate verification.
- Blank company chart cells (including DP) are not inferred. Manufacturer datasheet override remains available.

## Compatibility and validation
- Android `applicationId`: `com.fieldledger.app` (preserved).
- Android versionName/versionCode: `1.9.6` / `28`.
- Local storage/database key `fieldledger.personal.v2` preserved.
- Web and Android WebView HTML copies byte-identical.
- Inline JavaScript syntax check passed.
- Functional tests passed for BYA/NYY surface values, quick table conditions, conservative safety values, SP/DP/TP lookup and blank DP result.
- ZIP integrity check passed.
- Android APK build and physical-device UI test were not run.
