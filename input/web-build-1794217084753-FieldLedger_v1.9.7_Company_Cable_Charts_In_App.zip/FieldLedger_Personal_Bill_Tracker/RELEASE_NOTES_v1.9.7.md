# FieldLedger v1.9.7 — In-app Company Cable Reference Charts

- Added three supplied company BYA/NYY reference photos to the Cable & Breaker Reference screen.
- Added responsive chart previews with tap-to-enlarge full-screen viewer and Escape/outside-tap close behavior.
- Bundled images in both web and Android WebView assets so references work offline.
- Updated web service-worker cache to include the three company chart images.
- No electrical table values, calculations, PWD BOQ/Tender data, app ID, or local database key changed in this UI-only update.
