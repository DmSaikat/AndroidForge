# Company cable-reference source images

These are the original images supplied by the user and used as the internal BYA/NYY reference material in FieldLedger. All three charts are also displayed inside Measurement Tools → Cable & Breaker Reference; tapping a preview opens a full-screen image viewer.

These are company internal references, not PWD data. PWD Schedule of Rates data is restricted to BOQ & Tender and must not be used as an input to electrical calculations. Confirm the original company chart revision and cable/product conditions before using for a construction design.
