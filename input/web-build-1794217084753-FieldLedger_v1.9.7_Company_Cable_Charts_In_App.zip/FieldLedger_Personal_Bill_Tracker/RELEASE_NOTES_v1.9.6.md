# FieldLedger v1.9.6 — Company Cable Reference Separation

- Replaced PWD ampacity lookup in Cable & Breaker Reference and Load & Breaker Calculator with the three user-supplied company BYA/NYY charts.
- PWD SoR cable data remains confined to BOQ & Tender references; it is no longer an input to electrical current, cable capacity, breaker or voltage-drop calculations.
- Added BYA conduit/trunking range, NYY in-air/cable-tray and direct-buried ratings, plus BYA/NYY single-core 35°C clipped-to-surface ampacity, safety-margin and ECC values.
- Added company SP / DP / TP breaker data. Blank DP entries remain unavailable; no DP rating is inferred.
- Safety current uses the lower of the company table's printed safety value and the arithmetic derating of base current where those disagree, preventing the tool from overstating cable capacity.
- Retained manufacturer datasheet override, installation correction factors, load current, voltage-drop screening, fault/breaking-capacity input check and generic preliminary coordination screening.
- Preserved Android applicationId `com.fieldledger.app` and localStorage key `fieldledger.personal.v2`.
- This ZIP is AndroidForge source; it is not a compiled APK.
