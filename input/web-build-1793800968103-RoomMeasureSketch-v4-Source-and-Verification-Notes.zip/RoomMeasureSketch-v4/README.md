# Room Measure & Sketch v4 — corrected engineering prototype

## Target
Android 8.0+ (minSdk 26), Kotlin, Jetpack Compose, ARCore 1.49.0, SQLite.

## v4 corrections
- AR camera texture is bound on the GL render thread after the AR session/GL texture are ready.
- Camera UV coordinates are transformed using the active ARCore display geometry.
- Display rotation/viewport geometry is refreshed when device rotation or surface size changes.
- Floor corner hits are restricted to tracked upward-facing horizontal planes.
- Wall-height taps are restricted to vertical planes and paired on the same detected plane.
- Rejects duplicate floor taps and detects common self-intersecting polygon selections.
- Validates minimum polygon area before returning survey results.
- Releases ARCore session on activity destruction and pauses session before pausing GL.
- PNG export draws the measured polygon and labels each measured edge when AR coordinates exist.
- PDF polygon sketch labels each measured edge.
- Database version 3 adds a projects table and defensive additive migration for legacy room columns.
- UI warns when aggregate door/window deductions exceed gross wall area.

## Build and install
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this folder (`RoomMeasureSketch-v3`) in Android Studio.
3. Use JDK 17; allow Gradle sync and download dependencies.
4. Connect the target Android phone with USB debugging enabled.
5. Select the phone and press Run, or use Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Install the generated debug APK from `app/build/outputs/apk/debug/`.

## AR survey workflow
1. Launch the app and open Measure > Start true ARCore corner survey.
2. Scan the floor slowly until ARCore detects a horizontal plane.
3. Tap at least three floor perimeter corners in clockwise or counter-clockwise order.
4. Use Undo to remove the last corner; Finish returns measured X/Z points and edge lengths.
5. For height, switch to Wall height and tap two points on the same detected vertical wall plane.
6. Verify dimensions with a tape/laser meter before using the values in engineering deliverables.

## Explicit limitations (not represented as complete)
- No physical Redmi K20 Pro test has been performed in this environment. ARCore availability depends on Google Play Services for AR and device certification.
- Height measurement is the vertical difference between two taps on one detected vertical plane. The app cannot infer that those taps are exactly floor and ceiling junctions; the operator must select and verify them.
- Door/window inputs are still aggregate count × width × height. Individual opening IDs, wall association, position, wall elevations and per-wall net-area checks are not implemented.
- Project records are still associated by project-name text; a projects table is maintained, but full project CRUD, foreign-key relations, backup/restore and revision history are not implemented.
- PDF report remains a compact single-page field report; full professional title block, drawing scale, revision table, multi-page overflow handling and opening schedule need further work.
- AR polygon sketch/export is dimension-labelled but not a certified CAD drawing. Always independently verify critical dimensions.

## Accuracy and safety
ARCore is visual-inertial tracking/plane estimation, not a laser rangefinder. Reflective, plain, dark, poorly lit or textureless surfaces can reduce tracking quality. Confirm all critical room dimensions using a calibrated tape or laser distance meter.
