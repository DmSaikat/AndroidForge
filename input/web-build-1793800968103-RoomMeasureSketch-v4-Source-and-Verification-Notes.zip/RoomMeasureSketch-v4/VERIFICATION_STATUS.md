# Room Measure & Sketch — v4 verification status

This archive contains the existing v4 Android Studio source project. It is a source package, not a verified APK and not an accuracy-certified engineering instrument.

## Present in source (not device-verified)
- ARCore session and camera rendering setup
- Horizontal floor-plane corner selection
- Vertical-plane point selection for a basic two-point height measurement
- Edge-distance, polygon area, and perimeter calculations
- Basic duplicate-corner and self-intersection checks
- Manual room dimensions and room persistence
- Basic project-name grouping
- Aggregate door/window area deductions
- Basic polygon PNG and PDF export

## Known limitations
- No demonstrated build/compile result or physical-device test is included.
- AR accuracy, repeatability, drift, and measurement uncertainty have not been quantified.
- Wall height is a manually selected two-point vertical difference; it is not automatic floor-to-ceiling detection.
- No robust confidence/uncertainty model or calibration workflow is included.
- Door/window records are aggregate counts and dimensions, not individually located openings assigned to specific walls.
- No complete wall elevation drawing or full engineering drawing sheet is implemented.
- PDF output is a basic report, not a fully validated multi-page engineering drawing package.
- No Gradle wrapper is included; open the project in Android Studio with a compatible Gradle installation.

## Required before production use
1. Build successfully in Android Studio and resolve any build errors.
2. Confirm ARCore support and test on the target phone.
3. Compare repeated AR readings against a calibrated laser distance meter and record error by distance and surface condition.
4. Validate polygon area/perimeter and opening-deduction calculations with known test cases.
5. Verify PDF/PNG drawing dimensions against the stored measurement data.

Do not use this prototype as the sole basis for construction, fabrication, or safety-critical decisions. Verify dimensions independently with a calibrated measuring instrument.
