package com.roommeasure.sketch

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class RoomRecord(val id: Long, val project: String, val room: String, val length: Double, val width: Double, val height: Double, val notes: String, val corners: String = "", val openings: String = "")

class RoomDatabase(context: Context): SQLiteOpenHelper(context, "room_measure.db", null, 3) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE rooms (id INTEGER PRIMARY KEY AUTOINCREMENT, project TEXT NOT NULL, room TEXT NOT NULL, length REAL NOT NULL, width REAL NOT NULL, height REAL NOT NULL, notes TEXT NOT NULL DEFAULT '', corners TEXT NOT NULL DEFAULT '', openings TEXT NOT NULL DEFAULT '', updated_at INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_rooms_project ON rooms(project)")
        db.execSQL("CREATE TABLE projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Defensive, additive migration: retain legacy records regardless of whether v1 used
        // the column name `name` or `room`.
        val columns = mutableSetOf<String>()
        db.rawQuery("PRAGMA table_info(rooms)", null).use { c -> while (c.moveToNext()) columns.add(c.getString(1)) }
        if ("room" !in columns) {
            db.execSQL("ALTER TABLE rooms ADD COLUMN room TEXT NOT NULL DEFAULT ''")
            if ("name" in columns) db.execSQL("UPDATE rooms SET room=name WHERE room=''")
        }
        if ("project" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN project TEXT NOT NULL DEFAULT 'Imported project'")
        if ("length" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN length REAL NOT NULL DEFAULT 0")
        if ("width" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN width REAL NOT NULL DEFAULT 0")
        if ("height" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN height REAL NOT NULL DEFAULT 0")
        if ("notes" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN notes TEXT NOT NULL DEFAULT ''")
        if ("corners" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN corners TEXT NOT NULL DEFAULT ''")
        if ("openings" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN openings TEXT NOT NULL DEFAULT ''")
        if ("updated_at" !in columns) db.execSQL("ALTER TABLE rooms ADD COLUMN updated_at INTEGER NOT NULL DEFAULT 0")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_rooms_project ON rooms(project)")
        db.execSQL("CREATE TABLE IF NOT EXISTS projects (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)")
        db.execSQL("INSERT OR IGNORE INTO projects(name,created_at,updated_at) SELECT DISTINCT project, ?, ? FROM rooms", arrayOf(System.currentTimeMillis(), System.currentTimeMillis()))
    }
    fun save(record: RoomRecord): Long {
        val values = android.content.ContentValues().apply {
            put("project",record.project); put("room",record.room); put("length",record.length)
            put("width",record.width); put("height",record.height); put("notes",record.notes); put("corners",record.corners); put("openings",record.openings)
            put("updated_at",System.currentTimeMillis())
        }
        writableDatabase.execSQL("INSERT OR IGNORE INTO projects(name,created_at,updated_at) VALUES(?,?,?)", arrayOf(record.project,System.currentTimeMillis(),System.currentTimeMillis()))
        writableDatabase.execSQL("UPDATE projects SET updated_at=? WHERE name=?", arrayOf(System.currentTimeMillis(),record.project))
        return if (record.id > 0) { writableDatabase.update("rooms",values,"id=?",arrayOf(record.id.toString())); record.id }
        else writableDatabase.insertOrThrow("rooms",null,values)
    }
    fun all(): List<RoomRecord> {
        val result = mutableListOf<RoomRecord>()
        readableDatabase.rawQuery("SELECT id,project,room,length,width,height,notes,corners,openings FROM rooms ORDER BY updated_at DESC",null).use { c ->
            while(c.moveToNext()) result.add(RoomRecord(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4),c.getDouble(5),c.getString(6),c.getString(7),c.getString(8)))
        }
        return result
    }
    fun delete(id: Long) { writableDatabase.delete("rooms","id=?",arrayOf(id.toString())) }
}
