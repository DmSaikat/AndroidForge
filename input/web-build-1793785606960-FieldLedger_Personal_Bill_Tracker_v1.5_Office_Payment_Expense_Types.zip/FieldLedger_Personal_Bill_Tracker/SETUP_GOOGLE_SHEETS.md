# FieldLedger - Personal Bill Tracker (final update)

## What this release includes
- Personal factory/field visit records; no app-side office submission or approval workflow.
- Editable visit details, including Name/Engineer, Employee ID, Designation, Department, Bill Date, Visit Date, work scope, advance and payment reference.
- Multiple expenditure lines per visit. Each line stores only a description and amount; expense category and per-item expense date are intentionally omitted.
- Edit/delete individual expense lines and delete a complete visit with confirmation.
- Receipt-photo preview, compression and Android WebView native file-picker support.
- Home, Activity, Create, Budget and Debts bottom navigation. Budget and Debts open separate screens.
- Android WebView zoom controls disabled; the app keeps normal vertical scrolling.
- Print/export an individual visit, selected month, selected year, or all visits. Each visit has a separate A4 expenditure-bill page patterned after the supplied BD Technology paper form.
- Local JSON backup export/import, Google Sheets snapshot sync, and restore from Google Sheets.

## Google Sheets and Drive setup
1. Create a Google Sheet and copy its ID from the URL.
2. Create a Google Drive folder for receipt images and copy its folder ID.
3. Open https://script.google.com/ and create a project. Replace `Code.gs` with the file at `google-apps-script/Code.gs`.
4. In `Code.gs`, set `SPREADSHEET_ID`, `DRIVE_FOLDER_ID`, and `API_KEY`. Use a unique long random API key.
5. Deploy as a Web app, execute as **Me**, and set access to **Anyone**. Copy the deployment URL ending in `/exec`.
6. In FieldLedger, open the top-right menu -> **Connect Google Sheets**. Paste the `/exec` URL and the same API key.
7. Use **Sync now** for a backup or **Restore from Google Sheets** to recover the cloud snapshot. On restore, choose replace or merge.
8. If the Apps Script code changes later, open **Deploy -> Manage deployments -> Edit**, choose **New version**, and deploy again.

## Backup behavior
- Local changes are saved immediately on the device.
- If the device is offline, the latest local dataset remains saved and sync is queued. When the app regains connectivity while open, it retries. A failed request is retried after a delay.
- The app can export a local JSON backup and import one later. Keep backups in a safe location.
- Google Sheets stores a complete snapshot in the `Visits` sheet. Each sync rewrites that generated sheet so deleted visits do not remain in the active backup. Do not manually edit the `Visits` sheet.
- Receipt images are compressed before upload and stored in the selected Drive folder. When restored, previously uploaded receipt images appear as Drive links.

## Security and known limitations
- This is intended for one engineer's personal record-keeping. It is not a multi-user finance or approval platform.
- The Apps Script deployment is publicly reachable and protected by a shared API key stored on the device. Anyone who obtains both the URL and key could access or overwrite the dataset. Do not store highly sensitive information; rotate the key if exposed.
- Sync is best-effort while the app is open. It is not a guaranteed Android background job after the app is closed or the process is killed.
- Use one primary device at a time. Multi-device conflict resolution is not implemented.
- If the phone is lost or app data is cleared before a successful cloud sync/local JSON export, unsynced records may be lost.
- A very large number of long expenditure descriptions can cause an individual report to continue onto another page; the report avoids silently clipping bill details.

## Printed expenditure bill
The print form follows the supplied paper template: BD Technology Limited letterhead and logo; Name, ID, Designation, Department, Bill Date, Expense Date and Signature; Factory/Project and Work Scope; serial-numbered Particulars/Taka table; Total; amount in words; advance/expenditure/balance summary; and Recommended By, Approved By and Received By signature lines. The signature lines are printed blanks only; the app does not submit bills or manage approvals.

## Print/export layout
Each selected visit starts on its own A4 expenditure-bill page. The bill lists particulars and taka values, sums the total, spells the amount in words, and includes the BD Technology signature lines. Month/year exports place the selected visits consecutively, one visit per page for normal-sized entries.
