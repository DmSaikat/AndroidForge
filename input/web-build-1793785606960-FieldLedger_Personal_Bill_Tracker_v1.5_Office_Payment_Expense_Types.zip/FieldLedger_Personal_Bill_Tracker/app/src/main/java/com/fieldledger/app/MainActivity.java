package com.fieldledger.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER_REQUEST = 9001;
    private static final int BACKUP_CREATE_REQUEST = 9002;
    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingBackupJson = null;
    private String pendingBackupName = "FieldLedger_Backup.json";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, FILE_CHOOSER_REQUEST);
                    return true;
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    return false;
                }
            }
        });
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String scheme = uri.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception ignored) { }
                    return true;
                }
                return false;
            }
        });
        webView.addJavascriptInterface(new FieldLedgerBridge(), "FieldLedgerBridge");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class FieldLedgerBridge {
        @JavascriptInterface public void exportPdf(String html, String title) {
            runOnUiThread(() -> {
                WebView reportView = new WebView(MainActivity.this);
                reportView.getSettings().setJavaScriptEnabled(true);
                reportView.getSettings().setAllowFileAccess(true);
                reportView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter("FieldLedger_" + title.replaceAll("[^A-Za-z0-9_-]", "_"));
                        PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("fieldledger", "FieldLedger", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        printManager.print("FieldLedger - " + title, adapter, attributes);
                    }
                });
                reportView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface public void sync(String raw) {
            executor.execute(() -> {
                boolean ok = false; String message = "Network error"; HttpURLConnection c = null;
                try {
                    JSONObject obj = new JSONObject(raw);
                    String endpoint = obj.getString("url"); obj.remove("url");
                    URL u = new URL(endpoint); c = (HttpURLConnection) u.openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true); c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000); c.setReadTimeout(60000);
                    c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    byte[] bytes = obj.toString().getBytes(StandardCharsets.UTF_8);
                    try (OutputStream os = c.getOutputStream()) { os.write(bytes); }
                    int code = c.getResponseCode();
                    InputStream is = (code >= 400) ? c.getErrorStream() : c.getInputStream();
                    String response = readAll(is);
                    JSONObject result; try { result = new JSONObject(response); } catch (Exception ignored) { result = new JSONObject(); }
                    ok = (code >= 200 && code < 300) && result.optBoolean("ok", false);
                    message = ok ? "Synced " + result.optInt("synced", 0) + " visit(s)" : "HTTP " + code + ": " + result.optString("error", response.isEmpty() ? "Unexpected server response" : response);
                } catch (Exception e) { message = e.getMessage() == null ? "Sync failed" : e.getMessage(); }
                finally { if (c != null) c.disconnect(); }
                final boolean success = ok; final String msg = message;
                runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("window.onFieldLedgerSyncResult(" + success + "," + JSONObject.quote(msg) + ")", null); });
            });
        }

        @JavascriptInterface public void restore(String endpoint, String apiKey) {
            executor.execute(() -> {
                boolean ok = false; String response = "Network error"; HttpURLConnection c = null;
                try {
                    String sep = endpoint.contains("?") ? "&" : "?";
                    URL u = new URL(endpoint + sep + "apiKey=" + URLEncoder.encode(apiKey, "UTF-8"));
                    c = (HttpURLConnection) u.openConnection(); c.setRequestMethod("GET"); c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000); c.setReadTimeout(60000);
                    int code = c.getResponseCode(); response = readAll(code >= 400 ? c.getErrorStream() : c.getInputStream());
                    JSONObject result = new JSONObject(response); ok = code >= 200 && code < 300 && result.optBoolean("ok", false);
                    if (!ok) response = result.optString("error", response);
                } catch (Exception e) { response = e.getMessage() == null ? "Restore failed" : e.getMessage(); }
                finally { if (c != null) c.disconnect(); }
                final boolean success = ok; final String msg = response;
                runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("window.onFieldLedgerRestoreResult(" + success + "," + JSONObject.quote(msg) + ")", null); });
            });
        }

        @JavascriptInterface public void saveBackup(String content, String fileName) {
            runOnUiThread(() -> {
                pendingBackupJson = content;
                pendingBackupName = fileName == null ? "FieldLedger_Backup.json" : fileName;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, pendingBackupName);
                startActivityForResult(intent, BACKUP_CREATE_REQUEST);
            });
        }
    }

    private String readAll(InputStream is) throws Exception {
        if (is == null) return "";
        try (InputStream in = is; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toString("UTF-8");
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST) {
            if (filePathCallback != null) {
                Uri[] results = FileChooserParams.parseResult(resultCode, data);
                filePathCallback.onReceiveValue(results);
                filePathCallback = null;
            }
        } else if (requestCode == BACKUP_CREATE_REQUEST) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new IllegalStateException("Could not open the selected file");
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    webView.evaluateJavascript("alert('Backup file saved successfully.')", null);
                } catch (Exception e) {
                    webView.evaluateJavascript("alert(" + JSONObject.quote("Backup save failed: " + e.getMessage()) + ")", null);
                }
            }
            pendingBackupJson = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        executor.shutdown();
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
