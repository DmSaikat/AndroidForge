// FieldLedger Personal Bill Tracker - Google Sheets + Drive backup/restore.
// Deploy as Web app: Execute as Me; access Anyone. The shared API key is a convenience control, not strong authentication.
const SPREADSHEET_ID = 'PASTE_SPREADSHEET_ID_HERE';
const DRIVE_FOLDER_ID = 'PASTE_DRIVE_FOLDER_ID_HERE';
const API_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
const SHEET_NAME = 'Visits';
const HEADERS = ['Visit ID','Last Synced','Factory','Engineer','Visit Date','Advance','Expenses Total','Work Scope','Record JSON'];

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!validKey_(body.apiKey)) return out_({ok:false,error:'Unauthorized'});
    const visits = (body.data && Array.isArray(body.data.visits)) ? body.data.visits : null;
    if (!visits) return out_({ok:false,error:'Missing visits array'});
    const folder = DRIVE_FOLDER_ID && DRIVE_FOLDER_ID !== 'PASTE_DRIVE_FOLDER_ID_HERE' ? DriveApp.getFolderById(DRIVE_FOLDER_ID) : null;
    visits.forEach((v, vi) => {
      (v.expenses || []).forEach((exp, ei) => {
        exp.receipts = (exp.receipts || []).map((receipt, ri) => {
          if (typeof receipt !== 'string' || !receipt.startsWith('data:image/')) return receipt;
          if (!folder) throw new Error('Set DRIVE_FOLDER_ID before syncing receipt photos.');
          const parts = receipt.split(',');
          const mime = (parts[0].match(/data:(.*);base64/) || [])[1] || 'image/jpeg';
          const bytes = Utilities.base64Decode(parts[1]);
          const digest = Utilities.computeDigest(Utilities.DigestAlgorithm.MD5, bytes);
          const contentKey = Utilities.base64EncodeWebSafe(digest).replace(/=+$/g, '');
          const name = 'FieldLedger_' + String(v.id) + '_expense' + ei + '_receipt' + ri + '_' + contentKey + '.jpg';
          const existing = folder.getFilesByName(name);
          if (existing.hasNext()) return existing.next().getId();
          return folder.createFile(Utilities.newBlob(bytes, mime, name)).getId();
        });
      });
    });
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName(SHEET_NAME);
    if (!sh) sh = ss.insertSheet(SHEET_NAME);
    const rows = [HEADERS];
    const now = new Date();
    visits.forEach(v => rows.push([
      String(v.id || ''), now, v.factory || '', v.engineer || '', v.visitDate || '',
      Number(v.advance || 0), (v.expenses || []).reduce((sum, item) => sum + Number(item.amount || 0), 0),
      v.scope || '', JSON.stringify(v)
    ]));
    sh.clearContents();
    sh.getRange(1, 1, rows.length, HEADERS.length).setValues(rows);
    sh.setFrozenRows(1);
    return out_({ok:true,synced:visits.length,at:now.toISOString()});
  } catch (err) {
    return out_({ok:false,error:String(err)});
  } finally {
    try { lock.releaseLock(); } catch (ignored) {}
  }
}

function doGet(e) {
  try {
    const key = e && e.parameter ? e.parameter.apiKey : '';
    if (!validKey_(key)) return out_({ok:false,error:'Unauthorized'});
    if (!SPREADSHEET_ID || SPREADSHEET_ID === 'PASTE_SPREADSHEET_ID_HERE') throw new Error('Set SPREADSHEET_ID in Code.gs.');
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sh = ss.getSheetByName(SHEET_NAME);
    if (!sh || sh.getLastRow() < 2) return out_({ok:true,data:{visits:[]},synced:0});
    const values = sh.getRange(2, 9, sh.getLastRow() - 1, 1).getValues();
    const visits = [];
    values.forEach(row => {
      if (!row[0]) return;
      try { const v = JSON.parse(String(row[0])); if (v && v.id) visits.push(v); }
      catch (ignored) {}
    });
    return out_({ok:true,data:{visits:visits},synced:visits.length,at:new Date().toISOString()});
  } catch (err) {
    return out_({ok:false,error:String(err)});
  }
}

function validKey_(key) {
  return !!key && API_KEY && API_KEY !== 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET' && String(key) === API_KEY;
}
function out_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
