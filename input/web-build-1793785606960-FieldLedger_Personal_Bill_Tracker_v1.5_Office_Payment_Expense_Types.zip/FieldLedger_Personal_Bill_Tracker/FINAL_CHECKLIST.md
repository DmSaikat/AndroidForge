# FieldLedger 1.4 - Final source verification

## Included in this release
- Personal field-visit and bill tracking; no in-app office submission, review, approval, or rejection workflow.
- Editable visit details and employee information used by the print form.
- Multiple bill-item rows per visit, each with a manual description and amount. Individual items can be edited or deleted.
- Full visit deletion with a confirmation prompt.
- Optional receipt photos, preview, image compression, and Android WebView file selection bridge.
- Home, Activity, Create, Budget, and Balance/Debts bottom navigation.
- Android WebView zoom disabled while vertical scrolling and text entry remain enabled.
- Responsive mobile header and no horizontal overflow at 390 px in the smoke test.
- Per-visit, month, year, and all-visit A4 expenditure bill exports based on the supplied BD Technology paper form.
- Local JSON backup and import; Google Sheets/Drive snapshot backup and restore hooks.
- BD Technology mark, industrial banner, Android launcher icon, and app version 1.4 / versionCode 5.

## Checks performed
- Embedded app JavaScript: `node --check` passed.
- Google Apps Script: `node --check` passed.
- Android manifest XML: parsed successfully.
- Web and Android `index.html`, logo, and industrial banner assets: matched byte-for-byte.
- Browser smoke test at 390 x 844 CSS pixels: create visit, add multiple expenses, edit an expense, verify totals/balance, generate individual/month/year bill HTML, test amount-in-words, exercise receipt image compression, export/import local backup, use navigation, open/close the side menu, delete a visit, and check for JavaScript errors and horizontal overflow. Passed.
- Printed bill template: rendered and inspected as a one-page A4 PDF; the two-visit report test generated exactly two A4 pages.
- ZIP archive: validated after creation.

## Not verified in this environment
- The Android APK has not been compiled or installed on a physical phone because the Android SDK and Gradle executable are not available in this build environment.
- The Android native file chooser and Android PrintManager dialog still require a build/device test.
- Google Sheets/Drive backup and restore need the user's own spreadsheet ID, Drive folder ID, API key, and deployed Apps Script URL before live testing.
- Automatic sync retries while the app is open or when it resumes; this is not a guaranteed background Android job after the app is closed.

## Data and security cautions
- Keep the current installed app and export a local JSON backup before uninstalling or clearing app data.
- Google Apps Script is a personal single-engineer prototype. The shared API key is stored on the device; this is not strong account authentication. Do not distribute the configured app or use it as a multi-user/company-grade finance system.
- Use one primary phone at a time; multi-device conflict resolution is not implemented.
- Each visit starts a new A4 page in month/year exports. Very long descriptions or unusually large numbers of expense rows/receipt images may extend a visit onto additional pages rather than silently clipping content.
