# FieldLedger v1.5 — navigation and office payment update

- Removed the non-working Budget and Debts bottom navigation buttons.
- Added a working Office Payment screen to record additional money received from the office for a selected visit.
- Office payments are stored as individual dated entries with method, reference and note; each payment increases the visit balance.
- Added expenditure type dropdown: Rickshaw, CNG, Bike, Bus, Allowance, and Manual type.
- Added manual category input and included the category in visit details and individual expenditure bill particulars.
- Preserved older reimbursement amounts and existing visit records.
