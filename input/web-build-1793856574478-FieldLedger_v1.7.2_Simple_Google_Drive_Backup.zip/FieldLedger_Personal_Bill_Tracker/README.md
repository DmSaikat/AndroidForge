# FieldLedger — BD Technology Personal Bill Tracker

## Version 1.7.2 — Simple Google Drive file backup

FieldLedger remains a local-first personal record book. It does not require a FieldLedger login, cloud recovery code, Apps Script deployment, or a custom backend.

### Simple backup and restore

- **Back up to Google Drive:** FieldLedger creates a complete JSON backup and opens the Android save screen. Choose Google Drive and save the file in a folder you can find again.
- **Restore from Google Drive:** FieldLedger opens the Android document picker. Choose the saved JSON backup.
- The same Google account must be available in the Android Google Drive app/provider to access that Drive file. This is Google Drive access, not a FieldLedger login.
- Backup is manual, not automatic. Save a new backup after important changes.
- The app records when a backup file was created, but it cannot independently verify that the selected destination was Google Drive.

### Restore modes

- **MERGE** adds visits from the backup. For matching visit IDs, it keeps the visit with the newer `updatedAt` timestamp. Visits already on the phone but absent from the backup are retained.
- **REPLACE** replaces the current local database with the selected backup. Use this only when you intend to replace the current records.
- Invalid files are rejected before the local database is changed.

### Existing data and upgrade

The Android application ID remains `com.fieldledger.app`, and the local database key remains `fieldledger.personal.v2`. Install this APK as an update over the existing FieldLedger app; do not uninstall the old version first. A normal in-place update preserves local app data.

The backup format remains compatible with FieldLedger v1.7.1 JSON exports. Receipt photos embedded as image data are included in the backup. Existing receipt references that are Google Drive file IDs remain references to those original Drive files; they are not downloaded and embedded by this manual backup feature. For those older references, keep access to the Google account that stores the receipt files.

### Existing features preserved

- Visit creation, editing and deletion.
- Expenditure entries including Transport, Rickshaw, CNG, Bike, Bus, Allowance and custom categories.
- Office payments, advances, cash returned and visit balances.
- Receipt images and individual bill exports.
- Monthly and yearly summary exports.
- Measurement Tools, calculator, unit converter and electrical calculation references.
- BD Technology branding and existing navigation.

### Build

Upload this project ZIP to AndroidForge, choose Android (APK), and build. This ZIP is source code, not a compiled APK.

### Limitations

- The app cannot back up automatically to Drive without a cloud integration.
- User must choose Google Drive in the Android save/open document picker.
- A file saved only on local storage does not protect against phone loss.
- Test one backup and restore before relying on it.

### Previous v1.7.1 cloud files

This version does not use the old Apps Script endpoint. It does not delete the old FieldLedger Drive vault, backup snapshots, or receipt folder. Keep those files in Drive until you have successfully created and tested a v1.7.2 manual backup. Legacy receipt IDs in visit records still point to those original Drive files.
