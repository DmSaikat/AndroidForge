package com.fieldledger.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        webView.setWebChromeClient(new WebChromeClient()); webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new SheetsBridge(), "FieldLedgerBridge");
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    private class SheetsBridge {
        @JavascriptInterface public void exportPdf(String html, String title) {
            runOnUiThread(() -> {
                WebView reportView = new WebView(MainActivity.this);
                reportView.getSettings().setJavaScriptEnabled(true);
                reportView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        PrintManager printManager = (PrintManager) getSystemService(PRINT_SERVICE);
                        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter("FieldLedger_" + title.replaceAll("[^A-Za-z0-9_-]", "_"));
                        PrintAttributes attributes = new PrintAttributes.Builder()
                                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new PrintAttributes.Resolution("fieldledger", "FieldLedger", 300, 300))
                                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                .build();
                        printManager.print("FieldLedger - " + title, adapter, attributes);
                    }
                });
                reportView.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null);
            });
        }
        @JavascriptInterface public void sync(String raw) {
            executor.execute(() -> {
                boolean ok=false; String message="Network error";
                HttpURLConnection c=null;
                try {
                    JSONObject obj=new JSONObject(raw);
                    String endpoint=obj.getString("url");
                    obj.remove("url");
                    URL u=new URL(endpoint); c=(HttpURLConnection)u.openConnection();
                    c.setRequestMethod("POST"); c.setDoOutput(true); c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(20000); c.setReadTimeout(60000);
                    c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                    byte[] bytes=obj.toString().getBytes(StandardCharsets.UTF_8);
                    try(OutputStream os=c.getOutputStream()){os.write(bytes);}
                    int code=c.getResponseCode();
                    InputStream is=(code>=400)?c.getErrorStream():c.getInputStream();
                    String response="";
                    if(is!=null){
                        try(InputStream in=is; ByteArrayOutputStream out=new ByteArrayOutputStream()){
                            byte[] buffer=new byte[8192]; int n;
                            while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
                            response=out.toString("UTF-8");
                        }
                    }
                    JSONObject result;
                    try{result=new JSONObject(response);}catch(Exception ignored){result=new JSONObject();}
                    ok=(code>=200&&code<300)&&result.optBoolean("ok",false);
                    message=ok?"Synced "+result.optInt("synced",0)+" visit(s)":"HTTP "+code+": "+result.optString("error",response.isEmpty()?"Unexpected server response":response);
                } catch(Exception e){ message=e.getMessage()==null?"Sync failed":e.getMessage(); }
                finally { if(c!=null)c.disconnect(); }
                final boolean success=ok; final String msg=message.replace("\\","\\\\").replace("'","\\'").replace("\n"," ").replace("\r"," ");
                runOnUiThread(() -> webView.evaluateJavascript("window.onFieldLedgerSyncResult("+success+",'"+msg+"')", null));
            });
        }
    }
    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed(); }
}
