package com.roommeasure.sketch

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as NativeCanvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.ar.core.ArCoreApk
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.abs
import kotlin.math.hypot

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { RoomMeasureApp() } }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomMeasureApp() {
    val context = LocalContext.current
    val db = remember { RoomDatabase(context.applicationContext) }
    var records by remember { mutableStateOf(db.all()) }
    var currentId by remember { mutableLongStateOf(0L) }
    var project by remember { mutableStateOf("New project") }
    var room by remember { mutableStateOf("Room 01") }
    var length by remember { mutableStateOf("12") }
    var width by remember { mutableStateOf("10") }
    var height by remember { mutableStateOf("9") }
    var notes by remember { mutableStateOf("") }
    var cameraStatus by remember { mutableStateOf("Camera measurement: not started") }
    var tab by remember { mutableIntStateOf(0) }
    var saved by remember { mutableStateOf(false) }
    var referencePhoto by remember { mutableStateOf<Bitmap?>(null) }
    var arCorners by remember { mutableStateOf("") }; var arEdges by remember { mutableStateOf("") }
    var doorCount by remember { mutableStateOf("1") }; var doorWidth by remember { mutableStateOf("3") }; var doorHeight by remember { mutableStateOf("7") }
    var windowCount by remember { mutableStateOf("1") }; var windowWidth by remember { mutableStateOf("4") }; var windowHeight by remember { mutableStateOf("4") }
    val arLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if(result.resultCode == android.app.Activity.RESULT_OK) {
            val data=result.data; val perimeterM=data?.getDoubleExtra("perimeter_m",0.0) ?: 0.0
            val spanX=data?.getDoubleExtra("span_x_m",0.0) ?: 0.0; val spanZ=data?.getDoubleExtra("span_z_m",0.0) ?: 0.0
            val areaM2=data?.getDoubleExtra("floor_area_m2",0.0) ?: 0.0
            val hM=data?.getFloatExtra("height_m",0f) ?: 0f
            val xz=data?.getFloatArrayExtra("corner_xz")
            if(perimeterM>0 && areaM2>0) { length=String.format(Locale.US,"%.2f",maxOf(spanX,spanZ)*3.28084); width=String.format(Locale.US,"%.2f",minOf(spanX,spanZ)*3.28084); if(hM>0) height=String.format(Locale.US,"%.2f",hM*3.28084); arCorners=xz?.joinToString(",") ?: ""; arEdges=data?.getFloatArrayExtra("edge_lengths_m")?.joinToString { String.format(Locale.US,"%.2f m",it) } ?: ""; cameraStatus="ARCore captured ${xz?.size?.div(2) ?: 0} floor corners; area ${fmt(areaM2*10.7639)} sq ft; edge lengths ${arEdges}; perimeter ${fmt(perimeterM*3.28084)} ft. Bounding dimensions are approximate." }
        }
    }
    val photoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap -> referencePhoto = bitmap; if (bitmap != null) cameraStatus = "Reference photo captured. Enter verified dimensions below; photo scale is not automatically calibrated." }
    val l = length.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val w = width.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val h = height.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val area = if(arCorners.isNotBlank()) polygonAreaSqFt(arCorners) else l * w
    val perimeter = if(arCorners.isNotBlank()) polygonPerimeterFt(arCorners) else 2 * (l + w)
    val wallArea = perimeter * h
    val volume = area * h
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) { cameraStatus = "Camera ready. Capture a room reference photo."; photoLauncher.launch(null) } else cameraStatus = "Camera permission denied; manual measurement remains available."
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF176B87), secondary = Color(0xFF4E8C79), background = Color(0xFFF5F7FA))) {
        Scaffold(topBar = { TopAppBar(title = { Column { Text("Room Measure & Sketch", fontWeight = FontWeight.Bold); Text("Field measurement notebook", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) } }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Measure", "Sketch", "Document", "Projects").forEachIndexed { i, label ->
                        FilterChip(selected = tab == i, onClick = { tab = i }, label = { Text(label) })
                    }
                }
                when (tab) {
                    0 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Project details", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                OutlinedTextField(project, { project = it; saved = false }, label = { Text("Project name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(room, { room = it; saved = false }, label = { Text("Room name / ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Camera-assisted measurement", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                Text("ARCore plane detection: scan the floor slowly, tap corners clockwise, and finish to calculate distances and polygon area. Device support must be confirmed on-site.", fontSize = 12.sp, color = Color.DarkGray)
                                OutlinedButton(onClick = { arLauncher.launch(android.content.Intent(context, ArMeasureActivity::class.java)) }, modifier = Modifier.fillMaxWidth()) { Text("Start true ARCore corner survey") }
                                Button(onClick = {
                                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                                        cameraStatus = try { "ARCore: ${ArCoreApk.getInstance().checkAvailability(context)}. Capture a reference photo; verify dimensions manually." } catch (_: Exception) { "Camera ready. Manual verification required." }
                                        photoLauncher.launch(null)
                                    } else permission.launch(Manifest.permission.CAMERA)
                                }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CameraAlt, null); Spacer(Modifier.width(8.dp)); Text("Capture room reference photo") }
                                Text(cameraStatus, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                referencePhoto?.let { Image(bitmap = it.asImageBitmap(), contentDescription = "Room reference photo", modifier = Modifier.fillMaxWidth().height(190.dp)) }
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Manual dimensions", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                DimensionField("Length", length) { length = it; saved = false }
                                DimensionField("Width", width) { width = it; saved = false }
                                DimensionField("Height", height) { height = it; saved = false }
                                Text("Enter decimal feet (example: 10.5 = 10 ft 6 in).", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                    1 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("2D floor sketch", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                RoomSketch(l, w, Modifier.fillMaxWidth().height(270.dp), arCorners)
                                Text(if(arCorners.isNotBlank()) "AR edge lengths (metres): $arEdges\nCorner X/Z (metres): $arCorners" else "Rectangular schematic from current dimensions. Capture AR corners for polygon survey.", fontSize = 10.sp, color = Color.Gray)
                                Text("Not a certified construction drawing; verify dimensions on site.", fontSize = 11.sp, color = Color.Gray)
                                Text("L = ${ftIn(l)}     W = ${ftIn(w)}", fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                    2 -> {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("Room summary", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                                SummaryRow("Floor area", "${fmt(area)} sq ft")
                                SummaryRow("Perimeter", "${fmt(perimeter)} ft")
                                val doorDeduction=(doorCount.toDoubleOrNull()?:0.0)*(doorWidth.toDoubleOrNull()?:0.0)*(doorHeight.toDoubleOrNull()?:0.0)
                                val windowDeduction=(windowCount.toDoubleOrNull()?:0.0)*(windowWidth.toDoubleOrNull()?:0.0)*(windowHeight.toDoubleOrNull()?:0.0)
                                val netWallArea=(wallArea-doorDeduction-windowDeduction).coerceAtLeast(0.0)
                                SummaryRow("Gross wall area", "${fmt(wallArea)} sq ft")
                                Text("Opening deductions", fontWeight=FontWeight.Bold)
                                DimensionField("Door count",doorCount){doorCount=it}; DimensionField("Door width",doorWidth){doorWidth=it}; DimensionField("Door height",doorHeight){doorHeight=it}
                                DimensionField("Window count",windowCount){windowCount=it}; DimensionField("Window width",windowWidth){windowWidth=it}; DimensionField("Window height",windowHeight){windowHeight=it}
                                SummaryRow("Door deduction", "${fmt(doorDeduction)} sq ft")
                                SummaryRow("Window deduction", "${fmt(windowDeduction)} sq ft")
                                if (doorDeduction + windowDeduction > wallArea) {
                                    Text("Warning: total opening deductions exceed gross wall area. Review opening dimensions before reporting.", color=Color(0xFFB3261E), fontSize=12.sp)
                                }
                                SummaryRow("Net wall area", "${fmt(netWallArea)} sq ft")
                                SummaryRow("Room volume", "${fmt(volume)} cu ft")
                                SummaryRow("Ceiling area", "${fmt(area)} sq ft")
                                OutlinedTextField(notes, { notes = it }, label = { Text("Notes / openings / site observations") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                                Button(onClick = { savePdf(context, project, room, l, w, h, notes + "\nAR corners (m): $arCorners\nAR edge lengths (m): $arEdges\nDoors: $doorCount x $doorWidth ft x $doorHeight ft\nWindows: $windowCount x $windowWidth ft x $windowHeight ft\nOpening deductions: ${fmt(doorDeduction+windowDeduction)} sq ft\nNet wall area: ${fmt(netWallArea)} sq ft", area, perimeter); saved = true }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Description, null); Spacer(Modifier.width(8.dp)); Text("Export PDF") }
                                OutlinedButton(onClick = { savePng(context, l, w, arCorners); }, modifier = Modifier.fillMaxWidth()) { Text("Export sketch as PNG") }
                                OutlinedButton(onClick = { currentId = db.save(RoomRecord(currentId, project, room, l, w, h, notes, arCorners, "doors=$doorCount,$doorWidth,$doorHeight;windows=$windowCount,$windowWidth,$windowHeight")); records = db.all(); saved = true; Toast.makeText(context, "Room saved offline", Toast.LENGTH_SHORT).show() }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save room offline") }
                                if (saved) Text("Reviewed / exported in this session", color = Color(0xFF28734D), fontSize = 12.sp)
                            }
                        }
                    }
                }
                if (tab == 3) {
                    Button(onClick = { currentId = 0L; project = "New project"; room = "Room 01"; length = "12"; width = "10"; height = "9"; notes = ""; tab = 0 }) { Text("New room") }
                    records.groupBy { it.project }.forEach { (name, rooms) ->
                        Text(name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        rooms.forEach { item ->
                            Card { Column(Modifier.fillMaxWidth().padding(12.dp)) {
                                Text("${item.room} • ${fmt(item.length * item.width)} sq ft")
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TextButton(onClick = { currentId = item.id; project = item.project; room = item.room; length = item.length.toString(); width = item.width.toString(); height = item.height.toString(); notes = item.notes; arCorners=item.corners
                                        item.openings.split(";").forEach { part ->
                                            val bits=part.substringAfter("=","").split(",")
                                            if(bits.size==3 && part.startsWith("doors=")){doorCount=bits[0];doorWidth=bits[1];doorHeight=bits[2]}
                                            if(bits.size==3 && part.startsWith("windows=")){windowCount=bits[0];windowWidth=bits[1];windowHeight=bits[2]}
                                        }
                                        tab = 0 }) { Text("Open") }
                                    TextButton(onClick = { db.delete(item.id); records = db.all(); if (currentId == item.id) currentId = 0L }) { Text("Delete") }
                                }
                            } }
                        }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF3F6))) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text("Live calculation", fontWeight = FontWeight.Bold)
                        SummaryRow("Floor area", "${fmt(area)} sq ft")
                        SummaryRow("Wall area", "${fmt(wallArea)} sq ft")
                        SummaryRow("Volume", "${fmt(volume)} cu ft")
                    }
                }
                Text("Measurement note: camera/AR results require on-site validation. For audit, installation and quantity-survey work, verify critical dimensions with a tape or laser distance meter.", fontSize = 11.sp, color = Color.Gray)
            }
        }
    }
}

@Composable fun DimensionField(label: String, value: String, onValue: (String) -> Unit) {
    OutlinedTextField(value, onValue, label = { Text("$label (ft)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth(), leadingIcon = { Icon(Icons.Default.Straighten, null) })
}
@Composable fun SummaryRow(label: String, value: String) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, fontSize = 13.sp); Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) } }
@Composable fun RoomSketch(length: Double, width: Double, modifier: Modifier = Modifier, corners: String = "") {
    Canvas(modifier.background(Color(0xFFFAFCFD))) {
        val maxW = size.width * .68f; val maxH = size.height * .58f
        val ratio = if (length > 0 && width > 0) length / width else 1.0
        val rw = if (ratio >= 1) maxW else maxH * ratio.toFloat()
        val rh = if (ratio >= 1) maxW / ratio.toFloat() else maxH
        val rect = RectF((size.width-rw)/2, (size.height-rh)/2, (size.width+rw)/2, (size.height+rh)/2)
        val values=corners.split(",").mapNotNull { it.toFloatOrNull() }
        if(values.size>=6 && values.size%2==0) {
            val xs=values.filterIndexed { i, _ -> i%2==0 }; val zs=values.filterIndexed { i, _ -> i%2==1 }
            val minX=xs.minOrNull()!!; val maxX=xs.maxOrNull()!!; val minZ=zs.minOrNull()!!; val maxZ=zs.maxOrNull()!!
            val sc=minOf(maxW/(maxX-minX).coerceAtLeast(.01f),maxH/(maxZ-minZ).coerceAtLeast(.01f))
            val ox=(size.width-(maxX-minX)*sc)/2; val oy=(size.height-(maxZ-minZ)*sc)/2
            val poly=Path().apply { values.indices.step(2).forEach { i -> val x=ox+(values[i]-minX)*sc; val y=oy+(values[i+1]-minZ)*sc; if(i==0) moveTo(x,y) else lineTo(x,y) }; close() }
            drawPath(poly,Color(0xFFE5F0F3)); drawPath(poly,Color(0xFF176B87),style=Stroke(width=4f))
        } else {
            drawRect(Color(0xFFE5F0F3), Offset(rect.left, rect.top), androidx.compose.ui.geometry.Size(rect.width(), rect.height()))
            drawRect(Color(0xFF176B87), Offset(rect.left, rect.top), androidx.compose.ui.geometry.Size(rect.width(), rect.height()), style = Stroke(width = 4f))
        }
        drawContext.canvas.nativeCanvas.drawText("${ftIn(length)}", rect.centerX(), rect.top-14, Paint().apply { color = android.graphics.Color.DKGRAY; textSize = 30f; textAlign = Paint.Align.CENTER })
        drawContext.canvas.nativeCanvas.save(); drawContext.canvas.nativeCanvas.rotate(-90f, rect.left-18, rect.centerY())
        drawContext.canvas.nativeCanvas.drawText("${ftIn(width)}", rect.left-18, rect.centerY(), Paint().apply { color = android.graphics.Color.DKGRAY; textSize = 30f; textAlign = Paint.Align.CENTER })
        drawContext.canvas.nativeCanvas.restore()
    }
}

fun polygonAreaSqFt(csv:String):Double { val v=csv.split(",").mapNotNull{it.toDoubleOrNull()}; if(v.size<6||v.size%2!=0)return 0.0; var a=0.0; for(i in v.indices step 2){val j=(i+2)%v.size;a+=v[i]*v[j+1]-v[j]*v[i+1]};return abs(a)/2.0*10.7639104 }
fun polygonPerimeterFt(csv:String):Double { val v=csv.split(",").mapNotNull{it.toDoubleOrNull()}; if(v.size<6||v.size%2!=0)return 0.0; var p=0.0; for(i in v.indices step 2){val j=(i+2)%v.size;p+=hypot(v[i]-v[j],v[i+1]-v[j+1])};return p*3.28084 }
fun fmt(v: Double) = String.format(Locale.US, "%.2f", v)
fun ftIn(v: Double): String { val feet = v.toInt(); val inches = ((v-feet)*12).toInt(); return "$feet' ${inches}\"" }

fun savePdf(context: android.content.Context, project: String, room: String, l: Double, w: Double, h: Double, notes: String, floorArea: Double = l*w, roomPerimeter: Double = 2*(l+w)) {
    val doc = PdfDocument(); val page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create()); val c = page.canvas
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; textSize = 18f; typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD) }
    c.drawText("ROOM MEASURE & SKETCH", 40f, 55f, p); p.textSize=12f; p.typeface=android.graphics.Typeface.DEFAULT
    val rows = listOf("Project: $project", "Room: $room", "Date: ${SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date())}", "", "Length: ${ftIn(l)} (${fmt(l)} ft)", "Width: ${ftIn(w)} (${fmt(w)} ft)", "Height: ${ftIn(h)} (${fmt(h)} ft)", "", "Floor / ceiling area: ${fmt(floorArea)} sq ft", "Perimeter: ${fmt(roomPerimeter)} ft", "Gross wall area: ${fmt(roomPerimeter*h)} sq ft", "Room volume: ${fmt(floorArea*h)} cu ft", "", "Notes: $notes", "", "Sketch is schematic; verify critical dimensions on site.")
    var y=95f; rows.forEach { c.drawText(it, 40f, y, p); y+=25f }
    val left=160f; val top=510f; val scale=if (l>0.0 && w>0.0) minOf(220f/l.toFloat(), 160f/w.toFloat()) else 10f
    val paint=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.rgb(23,107,135); style=Paint.Style.STROKE; strokeWidth=3f }
    val cornerLine=notes.lineSequence().firstOrNull { it.startsWith("AR corners (m):") }?.substringAfter(":")?.trim().orEmpty()
    val coords=cornerLine.split(",").mapNotNull { it.trim().toFloatOrNull() }
    if(coords.size>=6 && coords.size%2==0) {
        val xs=coords.filterIndexed { i, _ -> i%2==0 }; val zs=coords.filterIndexed { i, _ -> i%2==1 }
        val minX=xs.minOrNull()!!; val maxX=xs.maxOrNull()!!; val minZ=zs.minOrNull()!!; val maxZ=zs.maxOrNull()!!
        val sc=minOf(220f/(maxX-minX).coerceAtLeast(.01f),160f/(maxZ-minZ).coerceAtLeast(.01f)); val ox=left; val oy=top
        val path=android.graphics.Path()
        val pts=coords.indices.step(2).map { i -> android.graphics.PointF(ox+(coords[i]-minX)*sc,oy+(coords[i+1]-minZ)*sc) }
        pts.forEachIndexed { idx, pt -> if(idx==0) path.moveTo(pt.x,pt.y) else path.lineTo(pt.x,pt.y) }; path.close()
        paint.style=Paint.Style.FILL; paint.color=android.graphics.Color.rgb(229,240,243); c.drawPath(path,paint)
        paint.style=Paint.Style.STROKE; paint.strokeWidth=3f; paint.color=android.graphics.Color.rgb(23,107,135); c.drawPath(path,paint)
        p.textSize=10f; p.color=android.graphics.Color.DKGRAY; c.drawText("AR measured polygon floor plan",left,top-14,p)
        pts.forEachIndexed { idx, pt ->
            val next=pts[(idx+1)%pts.size]
            val metres=kotlin.math.hypot((coords[2*((idx+1)%pts.size)]-coords[2*idx]).toDouble(),(coords[2*((idx+1)%pts.size)+1]-coords[2*idx+1]).toDouble())
            c.drawText("W${idx+1} ${fmt(metres*3.28084)} ft",(pt.x+next.x)/2f,(pt.y+next.y)/2f-5f,p)
        }
    } else { c.drawRect(left, top, left+l.toFloat()*scale, top+w.toFloat()*scale, paint); p.textSize=11f; c.drawText("${ftIn(l)}", left, top-12, p); c.drawText("${ftIn(w)}", left-45, top+((w.toFloat()*scale)/2f), p) }
    doc.finishPage(page)
    val name="Room_${room.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${System.currentTimeMillis()}.pdf"
    val values=ContentValues().apply { put(MediaStore.Downloads.DISPLAY_NAME,name); put(MediaStore.Downloads.MIME_TYPE,"application/pdf"); put(MediaStore.Downloads.RELATIVE_PATH,"Download/RoomMeasureSketch") }
    val uri=context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,values)
    if(uri!=null) context.contentResolver.openOutputStream(uri)?.use { doc.writeTo(it) }
    doc.close(); Toast.makeText(context, if(uri!=null) "PDF saved to Downloads/RoomMeasureSketch" else "PDF export failed", Toast.LENGTH_LONG).show()
}
fun savePng(context: android.content.Context, l: Double, w: Double, corners: String = "") {
    val bmp=Bitmap.createBitmap(1200,900,Bitmap.Config.ARGB_8888); val c=NativeCanvas(bmp); c.drawColor(android.graphics.Color.WHITE)
    val p=Paint(Paint.ANTI_ALIAS_FLAG).apply { color=android.graphics.Color.rgb(23,107,135); style=Paint.Style.STROKE; strokeWidth=8f }
    val values=corners.split(",").mapNotNull { it.trim().toFloatOrNull() }
    if (values.size>=6 && values.size%2==0) {
        val xs=values.filterIndexed { i, _ -> i%2==0 }; val zs=values.filterIndexed { i, _ -> i%2==1 }
        val minX=xs.minOrNull()!!; val maxX=xs.maxOrNull()!!; val minZ=zs.minOrNull()!!; val maxZ=zs.maxOrNull()!!
        val sc=minOf(700f/(maxX-minX).coerceAtLeast(.01f),500f/(maxZ-minZ).coerceAtLeast(.01f))
        val ox=(1200-(maxX-minX)*sc)/2f; val oy=(900-(maxZ-minZ)*sc)/2f
        val pts=values.indices.step(2).map { i -> android.graphics.PointF(ox+(values[i]-minX)*sc,oy+(values[i+1]-minZ)*sc) }
        val path=android.graphics.Path().apply { pts.forEachIndexed { i, pt -> if(i==0) moveTo(pt.x,pt.y) else lineTo(pt.x,pt.y) }; close() }
        p.style=Paint.Style.FILL; p.color=android.graphics.Color.rgb(229,240,243); c.drawPath(path,p)
        p.style=Paint.Style.STROKE; p.strokeWidth=8f; p.color=android.graphics.Color.rgb(23,107,135); c.drawPath(path,p)
        p.style=Paint.Style.FILL; p.color=android.graphics.Color.DKGRAY; p.textSize=25f
        pts.forEachIndexed { i, pt ->
            val next=pts[(i+1)%pts.size]
            val metres=kotlin.math.hypot((values[2*((i+1)%pts.size)]-values[2*i]).toDouble(),(values[2*((i+1)%pts.size)+1]-values[2*i+1]).toDouble())
            c.drawText("W${i+1}: ${fmt(metres*3.28084)} ft",(pt.x+next.x)/2f,(pt.y+next.y)/2f-10f,p)
        }
        c.drawText("AR polygon floor plan",50f,55f,p)
    } else {
        val scale=if(l>0.0&&w>0.0) minOf(700f/l.toFloat(),500f/w.toFloat()) else 20f
        val left=(1200f-l.toFloat()*scale)/2f; val top=(900f-w.toFloat()*scale)/2f
        c.drawRect(left,top,left+l.toFloat()*scale,top+w.toFloat()*scale,p); p.style=Paint.Style.FILL; p.color=android.graphics.Color.DKGRAY; p.textSize=34f
        c.drawText("L ${ftIn(l)}",left,top-25,p); c.drawText("W ${ftIn(w)}",left,top+w.toFloat()*scale+55f,p)
    }
    val imageMetadata=ContentValues().apply { put(MediaStore.Images.Media.DISPLAY_NAME,"RoomSketch_${System.currentTimeMillis()}.png"); put(MediaStore.Images.Media.MIME_TYPE,"image/png"); put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/RoomMeasureSketch") }
    val uri=context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,imageMetadata); if(uri!=null) context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG,100,it) }
    bmp.recycle(); Toast.makeText(context,if(uri!=null) "PNG saved to Pictures/RoomMeasureSketch" else "PNG export failed",Toast.LENGTH_LONG).show()
}
