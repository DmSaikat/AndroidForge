package com.roommeasure.sketch

import android.app.Activity
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.ar.core.*
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.*

/** ARCore plane-hit survey. Tap floor corners in order; then use wall-height mode and tap a vertical plane. */
class ArMeasureActivity : Activity(), GLSurfaceView.Renderer {
    private lateinit var gl: GLSurfaceView
    private lateinit var status: TextView
    private var session: Session? = null
    private var installRequested = false
    @Volatile private var frame: Frame? = null
    private val floorHits = mutableListOf<FloatArray>()
    @Volatile private var heightMode = false
    @Volatile private var measuredHeight = 0f
    private val heightTaps = mutableListOf<Pair<Trackable, Float>>()
    private var textureBound = false
    private var lastDisplayRotation = -1
    private var program = 0
    private var texture = 0
    private lateinit var vertices: FloatBuffer
    private val vertexShader = "attribute vec4 aPosition; attribute vec2 aTexCoord; varying vec2 vTexCoord; void main(){gl_Position=aPosition;vTexCoord=aTexCoord;}"
    private val fragmentShader = "#extension GL_OES_EGL_image_external : require\nprecision mediump float; varying vec2 vTexCoord; uniform samplerExternalOES sTexture; void main(){gl_FragColor=texture2D(sTexture,vTexCoord);}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        status = TextView(this).apply { text = "Move slowly to detect planes. Tap floor corners clockwise."; textSize = 15f; setPadding(16,12,16,12) }
        gl = GLSurfaceView(this).apply { setEGLContextClientVersion(2); setRenderer(this@ArMeasureActivity); renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY }
        root.addView(status)
        root.addView(gl, LinearLayout.LayoutParams(-1,0,1f))
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        controls.addView(Button(this).apply { text = "Floor corner"; setOnClickListener { heightMode=false; status.text="Tap each visible floor corner in order. ${floorHits.size} selected." } }, LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(Button(this).apply { text = "Wall height"; setOnClickListener { heightMode=true; status.text="Aim at a vertical wall plane and tap near the floor or ceiling edge." } }, LinearLayout.LayoutParams(0,-2,1f))
        controls.addView(Button(this).apply { text = "Undo"; setOnClickListener { if(floorHits.isNotEmpty()) floorHits.removeAt(floorHits.lastIndex); status.text="${floorHits.size} floor corners selected" } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(controls)
        root.addView(Button(this).apply { text = "Finish & use measurements"; setOnClickListener { finishSurvey() } })
        setContentView(root)
        gl.setOnTouchListener { _, e -> if(e.action==MotionEvent.ACTION_UP) { val x=e.x; val y=e.y; gl.queueEvent { hit(x,y) }; true } else true }
        if(ContextCompat.checkSelfPermission(this,android.Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(android.Manifest.permission.CAMERA),41)
        } else initializeSession()
    }
    private fun initializeSession(){
        try {
            if (ArCoreApk.getInstance().checkAvailability(this).isTransient) { status.text="Checking ARCore availability… reopen AR survey shortly."; return }
            session = Session(this)
            val config = Config(session!!).apply { planeFindingMode=Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL; focusMode=Config.FocusMode.AUTO }
            session!!.configure(config)
        } catch (e: Exception) { Toast.makeText(this,"ARCore unavailable: ${e.message}",Toast.LENGTH_LONG).show(); status.text="ARCore could not start. Check Google Play Services for AR support and device compatibility." }
    }
    override fun onRequestPermissionsResult(requestCode:Int, permissions:Array<out String>, grantResults:IntArray){ super.onRequestPermissionsResult(requestCode,permissions,grantResults); if(requestCode==41 && grantResults.firstOrNull()==PackageManager.PERMISSION_GRANTED) initializeSession() else status.text="Camera permission is required for AR measurement." }
    override fun onResume(){ super.onResume(); try {
        if(ContextCompat.checkSelfPermission(this,android.Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED && session==null) {
            when(ArCoreApk.getInstance().requestInstall(this,!installRequested)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> { installRequested=true; return }
                ArCoreApk.InstallStatus.INSTALLED -> if(session==null) initializeSession()
            }
        }
        gl.onResume()
        session?.resume()
    } catch(e:Exception){ status.text="AR session error: ${e.message}" } }
    override fun onPause(){ session?.pause(); gl.onPause(); super.onPause() }
    override fun onDestroy(){ session?.close(); session=null; super.onDestroy() }
    override fun onSurfaceCreated(gl10: GL10?, config: EGLConfig?) {
        val ids=IntArray(1); GLES20.glGenTextures(1,ids,0); texture=ids[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR)
        program=link(vertexShader,fragmentShader)
        val v=floatArrayOf(-1f,-1f,0f,1f, 1f,-1f,1f,1f, -1f,1f,0f,0f, 1f,1f,1f,0f)
        vertices=ByteBuffer.allocateDirect(v.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(v).apply{position(0)}
    }
    override fun onSurfaceChanged(gl10: GL10?, width: Int, height: Int){ GLES20.glViewport(0,0,width,height) }
    override fun onDrawFrame(gl10: GL10?) {
        val s=session ?: run { GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT); return }
        try {
            if (!textureBound) { s.setCameraTextureNames(intArrayOf(texture)); textureBound = true }
            val rotation = windowManager.defaultDisplay.rotation
            if (rotation != lastDisplayRotation) {
                s.setDisplayGeometry(rotation, gl.width, gl.height)
                lastDisplayRotation = rotation
            }
            val f=s.update(); frame=f
            // ARCore camera UVs must be transformed for current display geometry.
            val inputUv = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            val outputUv = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
            inputUv.put(floatArrayOf(0f,1f, 1f,1f, 0f,0f, 1f,0f)).position(0)
            f.transformDisplayUvCoords(inputUv, outputUv)
            outputUv.position(0)
            for (i in 0..3) { vertices.put(i*4+2, outputUv.get()); vertices.put(i*4+3, outputUv.get()) }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUseProgram(program)
            vertices.position(0); val pos=GLES20.glGetAttribLocation(program,"aPosition"); GLES20.glEnableVertexAttribArray(pos); GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,16,vertices)
            vertices.position(2); val uv=GLES20.glGetAttribLocation(program,"aTexCoord"); GLES20.glEnableVertexAttribArray(uv); GLES20.glVertexAttribPointer(uv,2,GLES20.GL_FLOAT,false,16,vertices)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture); GLES20.glUniform1i(GLES20.glGetUniformLocation(program,"sTexture"),0)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4); GLES20.glDisableVertexAttribArray(pos); GLES20.glDisableVertexAttribArray(uv)
        } catch (_: Exception) { }
    }
    private fun hit(px:Float, py:Float) {
        val f=frame ?: return
        try {
            val hits=f.hitTest(px,py)
            val hit=hits.firstOrNull { h ->
                val t=h.trackable
                t is Plane && t.trackingState == TrackingState.TRACKING && t.isPoseInPolygon(h.hitPose) &&
                    (if (heightMode) t.type == Plane.Type.VERTICAL else t.type == Plane.Type.HORIZONTAL_UPWARD_FACING)
            }
            if(hit==null){ runOnUiThread { status.text="No detected plane at that point. Move slowly, scan the floor/wall, and retry." }; return }
            val pose=hit.hitPose
            if(heightMode) {
                val plane = hit.trackable as Plane
                if (heightTaps.isNotEmpty() && heightTaps.last().first != plane) heightTaps.clear()
                heightTaps.add(plane to pose.ty())
                if(heightTaps.size>=2) {
                    measuredHeight=abs(heightTaps[heightTaps.lastIndex].second-heightTaps[heightTaps.lastIndex-1].second)
                    heightTaps.clear()
                }
                runOnUiThread { status.text=if(heightTaps.isNotEmpty()) "First point on this wall recorded. Tap the opposite vertical edge on the same wall." else if(measuredHeight>0f) "Vertical separation: ${"%.3f".format(measuredHeight)} m. Verify floor-to-ceiling endpoints." else "Tap two vertical-wall points." }
            } else {
                val pt=floatArrayOf(pose.tx(),pose.ty(),pose.tz())
                if(floorHits.size >= 3 && isSelfCrossing(floorHits.map { it[0] to it[2] } + listOf(pt[0] to pt[2]))) {
                    runOnUiThread { status.text="That corner would cross an existing edge. Undo or select the next perimeter corner." }
                    return
                }
                if(floorHits.none { hypot(it[0]-pt[0],it[2]-pt[2])<0.08f }) floorHits.add(pt)
                runOnUiThread { status.text="${floorHits.size} floor corners selected. Continue clockwise; tap Finish when done." }
            }
        } catch(e:Exception){ runOnUiThread { status.text="Tap failed: ${e.message}" } }
    }
    private fun finishSurvey(){
        if(floorHits.size<3){ Toast.makeText(this,"Select at least 3 floor corners",Toast.LENGTH_SHORT).show(); return }
        if (abs(signedArea(floorHits)) < 0.01) { Toast.makeText(this,"Survey polygon area is too small or invalid",Toast.LENGTH_LONG).show(); return }
        val flat=floorHits.flatMap { listOf(it[0],it[2]) }.toFloatArray()
        val edges=floorHits.indices.map { i -> val a=floorHits[i]; val b=floorHits[(i+1)%floorHits.size]; hypot((a[0]-b[0]).toDouble(),(a[2]-b[2]).toDouble()).toFloat() }.toFloatArray()
        val area=abs(floorHits.indices.sumOf { i -> val a=floorHits[i]; val b=floorHits[(i+1)%floorHits.size]; (a[0]*b[2]-b[0]*a[2]).toDouble() })/2.0
        val perimeter=floorHits.indices.sumOf { i -> val a=floorHits[i]; val b=floorHits[(i+1)%floorHits.size]; hypot((a[0]-b[0]).toDouble(),(a[2]-b[2]).toDouble()) }
        val result=android.content.Intent().putExtra("corner_xz",flat).putExtra("floor_area_m2",area).putExtra("perimeter_m",perimeter).putExtra("height_m",measuredHeight).putExtra("edge_lengths_m",edges).putExtra("span_x_m",(floorHits.maxOf{it[0]}-floorHits.minOf{it[0]}).toDouble()).putExtra("span_z_m",(floorHits.maxOf{it[2]}-floorHits.minOf{it[2]}).toDouble())
        setResult(Activity.RESULT_OK,result); finish()
    }
    private fun signedArea(points: List<FloatArray>): Double = points.indices.sumOf { i ->
        val a=points[i]; val b=points[(i+1)%points.size]; (a[0]*b[2]-b[0]*a[2]).toDouble()
    } / 2.0
    private fun isSelfCrossing(points: List<Pair<Float,Float>>): Boolean {
        if (points.size < 4) return false
        fun orient(a:Pair<Float,Float>,b:Pair<Float,Float>,c:Pair<Float,Float>) =
            (b.first-a.first)*(c.second-a.second)-(b.second-a.second)*(c.first-a.first)
        for (i in 0 until points.size-1) for (j in i+2 until points.size-1) {
            if (i==0 && j==points.size-2) continue
            val a=points[i]; val b=points[i+1]; val c=points[j]; val d=points[j+1]
            if (orient(a,b,c)*orient(a,b,d)<0 && orient(c,d,a)*orient(c,d,b)<0) return true
        }
        return false
    }
    private fun compile(type:Int, source:String):Int { val id=GLES20.glCreateShader(type); GLES20.glShaderSource(id,source); GLES20.glCompileShader(id); return id }
    private fun link(v:String,f:String):Int { val p=GLES20.glCreateProgram(); GLES20.glAttachShader(p,compile(GLES20.GL_VERTEX_SHADER,v)); GLES20.glAttachShader(p,compile(GLES20.GL_FRAGMENT_SHADER,f)); GLES20.glLinkProgram(p); return p }
}
