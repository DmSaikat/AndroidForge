# FieldLedger - BD Technology Personal Bill Tracker

FieldLedger is a personal Android record book for field visits, advances, bill items, receipts and balances. It does not include office submission, approval or rejection workflows.

## Main features
- Editable visit details: factory/client, location, engineer/name, optional Employee ID, Designation and Department, Bill Date, Visit Date, manual Work Scope, advance and payment details.
- Multiple expenditure entries in one batch. Each line has only a description and amount (no category or expense date); edit or delete entries later.
- Delete a whole visit with a confirmation prompt.
- Receipt photo selection, preview and compression.
- Five-option fixed bottom navigation: Home, Activity, Create, Budget and Debts.
- Non-zooming Android WebView with normal scrolling and clipped off-screen menu overflow.
- Individual visit, monthly, yearly and all-visit A4 Expenditure Bill exports.
- Print layout mirrors the user's BD Technology paper form, including signature lines.
- Local JSON backup export/import plus Google Sheets/Drive backup and restore.

## Build
Upload the project ZIP to your AndroidForge-compatible builder, select **Android (APK)** and **Debug**, then build. This archive is source code, not a compiled APK.

## Configure backup
Follow `SETUP_GOOGLE_SHEETS.md` and update `google-apps-script/Code.gs` with your Sheet ID, Drive folder ID and unique API key before deploying the Apps Script Web App.
