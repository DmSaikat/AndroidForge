# FieldLedger 1.4.1 – Monthly/yearly summary export

- Individual visit export continues to use the full BD Technology expenditure bill form.
- Monthly and yearly exports now produce a compact period summary only: visit date, factory/project, advance received, expenditure, grand totals, and net balance.
- Monthly/yearly summaries do not print a full expenditure bill form for every visit and do not include itemized particulars.
- The same updated web interface is copied into Android app assets.
