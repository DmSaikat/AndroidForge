# FieldLedger Android project

Clean Java-only Android WebView project for the FieldLedger field-visit advance and expense tracker.

- Android package: `com.fieldledger.app`
- Main activity: `app/src/main/java/com/fieldledger/app/MainActivity.java`
- App UI: `app/src/main/assets/index.html`
- No Kotlin source files are included.
- Gradle Android plugin: 8.6.1; compile SDK 35; minimum SDK 23.

Build with AndroidForge using Android (APK), variant `debug` or `auto`.

## Prototype limitation
The app stores data locally in WebView local storage. It does not provide shared engineer/office accounts, cloud synchronization, or server-side approvals.
