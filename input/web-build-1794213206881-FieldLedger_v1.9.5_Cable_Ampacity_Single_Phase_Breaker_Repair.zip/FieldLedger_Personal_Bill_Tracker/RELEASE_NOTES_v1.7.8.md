# FieldLedger v1.7.8 — Employee Setup Shortcut

- Added a prominent Employee Details & Engineer Directory panel to the Overview screen.
- Added an Open employee setup action that opens the existing profile page.
- Added a live summary showing whether the primary employee profile is set and how many engineer profiles are saved.
- Existing profile form, engineer directory, visit assignments and billing integration are preserved.
- No database schema change or local storage key change.

Static source checks only; APK compilation and physical-device testing remain required.
