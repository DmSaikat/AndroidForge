# FieldLedger v1.7.6 — Remove Settlement Record from Visit Form

- Removed the optional Settlement Record panel from the Create Field Visit and Edit Visit form.
- Existing settlement, cash-return and reimbursement values remain preserved in saved visit records and are not cleared when editing other visit details.
- Existing balance summaries, Office Payment functionality, bill/report rendering and historical records are retained.
- No local database key or record schema migration is required.

Static source checks only; APK compilation and physical-device testing remain required.
