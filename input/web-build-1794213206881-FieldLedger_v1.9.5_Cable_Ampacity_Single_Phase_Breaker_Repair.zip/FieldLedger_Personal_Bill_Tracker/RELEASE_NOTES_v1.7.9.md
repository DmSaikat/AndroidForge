# FieldLedger v1.7.9 — Load & Breaker Calculator

- Added a dedicated Load & Breaker Calculator card under Measurement Tools.
- Added an editable multi-item load schedule with quantity, unit kW and per-item demand factor.
- Calculates connected kW, maximum-demand kW, electrical input kW, kVA and single-/three-phase design current.
- Added BYA single-core copper concealed/surface ampacity lookup from the Bangladesh Power Division guideline table.
- NYY requires a manufacturer/catalogue current rating for the exact construction, cores and installation; the tool does not guess.
- Added separate ambient, grouping, thermal/installation and other correction factors, then calculates corrected cable capacity.
- Added preliminary MCB/MCCB/ACB candidate rating using IB <= In <= IZ.
- Added optional prospective short-circuit level vs device breaking-capacity comparison.
- Explicitly identifies the remaining checks: I2 coordination, trip curves, fault-loop/disconnection time, cable short-circuit withstand, selectivity, motor starting and product data.
- Existing Electrical Calculator and Cable & Breaker Reference remain available.
- Android versionName 1.7.9, versionCode 18. Local database, backup and profile data unchanged.

Static checks and representative calculation tests only. APK compilation and physical-device testing remain required.
