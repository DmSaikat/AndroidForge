# FieldLedger v1.9.2 — Full PWD PDF search

- Added an offline full-text index of all 1,041 pages of the supplied Electrical_PWD.pdf (PWD SoR 2022 E/M Works).
- Search covers item numbers, descriptions, units, technical terms and extracted full-page text.
- Parsed item-row candidates show unit and four regional rate columns only when all four numeric values were extracted and passed conservative plausibility checks.
- OCR-derived prices are explicitly marked as candidates and must be checked against the original cited PDF page before tender use.
- Incomplete/ambiguous rows show source text and page references but cannot be auto-added as a PWD-priced item.
- Existing quick-pick PWD lines, manual items, BOQ take-off, calculations, rate analysis, saved projects and data storage key are preserved.
- Added the PDF index to the Android and web asset sets and service-worker precache.

## Extraction limits

The full PDF is searchable as extracted text, but it is a scanned/OCR-derived schedule. Not every item row has all four regional rates in a clean machine-readable row. The extraction identified 891 row candidates; 294 passed the four-rate consistency gate, including 142 rows read without character substitution and 152 rows where selected OCR character substitutions were needed. These are all rate candidates, not independently verified price certifications. Reconstructed rows are separately flagged. The remaining item candidates and all full page text are searchable, but incomplete prices must be manually checked against the original PDF scan. Vehicle repair pages with model-specific columns are not treated as four regional rate tables.

PWD SoR 2022 is a historical reference only. Confirm the applicable schedule/circular and tender conditions before submission.


## Superseded by v1.9.3
The 294 OCR-derived price candidates previously described above have been disabled and their price fields removed from structured search rows. Do not use v1.9.2 OCR price candidates for BOQ pricing. v1.9.3 enables only manually visually checked source-scan prices.
