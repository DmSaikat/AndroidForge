# Code review — v1.7.5

Changes: unlimited per-visit engineer assignments; exactly one primary role; reusable engineer directory; optional engineer photo; bill export lists all assigned engineers; legacy single-engineer records remain supported.

Compatibility: existing `fieldledger.personal.v2` database key and visit fields retained. `db.engineers` and `visit.assignedEngineers` are additive fields. Existing backup serializes the complete database object, so directory and assignments are included.

Limitations: the source has not been compiled into an APK or tested on a physical Android device. Large profile photos can increase backup JSON size. The directory and photos remain local until included in a manual JSON backup.
