# FieldLedger v1.8.1 — Home-only Dashboard

- Moved the dashboard title / New Site Visit shortcut and all four summary cards inside the Overview (Home) section.
- Dashboard content now follows the existing section visibility navigation and is hidden on My Visits, Profile, Create Visit, Visit Details, Office Payment and Measurement Tools.
- Persistent navigation tabs remain available so users can change pages.
- Dashboard summary calculations, employee setup, visits, expenses, engineer assignments, measurement tools and backup logic are unchanged.
- Android versionName 1.8.1, versionCode 20.

Static source checks only; APK compilation and physical-device testing remain required.
