# FieldLedger v1.7.3

## Google Drive backup visibility
- Added a persistent Backup & Appearance panel on the Home screen.
- Kept backup and restore actions in the navigation drawer.
- Android backup opens the system Save screen; select Google Drive as the destination.
- Android restore opens the system document picker; choose the JSON backup stored in Google Drive.
- Browser fallback downloads/uploads a JSON file; it does not silently sync to Drive.

## Dark mode
- Added Light/Dark toggle on the Home screen and navigation drawer.
- Theme preference is saved locally and restored on app launch.
- Updated app surface, cards, forms, menus, buttons, and bottom navigation for dark mode.
- Android status/navigation bars follow the selected theme.

## Compatibility
- Preserved applicationId `com.fieldledger.app`.
- Preserved local database key `fieldledger.personal.v2`.
- Existing backup JSON format remains readable.
