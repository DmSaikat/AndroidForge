# Code review — FieldLedger v1.9.1 BOQ calculations

## Static checks completed
- Parsed both HTML entry points and checked for duplicate static element IDs: none found.
- Extracted inline JavaScript from both HTML files and ran `node --check`: passed.
- Confirmed `web/index.html` and `app/src/main/assets/index.html` are byte-identical.
- Confirmed application ID `com.fieldledger.app`, local database key `fieldledger.personal.v2`, versionCode 23 and versionName 1.9.1.
- Confirmed the BOQ calculation, quantity register, rate analysis and print-register functions are present.
- Independent formula spot checks passed for Appendix B load density, Appendix F changeover multiplier, Appendix G ECC band, Appendix H labour cost, cable route quantity and a sample custom unit-rate build-up.
- ZIP archive integrity is verified after packaging.

## Important not tested
- AndroidForge/GitHub Actions APK build was not run.
- Physical Android/WebView interaction, persistence after restart, and print/PDF rendering were not verified on a device. A headless browser smoke test did not complete reliably, so no runtime/device pass is claimed.
- PDF source catalogue remains a curated starter set rather than a complete extraction of all 1,041 pages.

## Engineering / procurement cautions
- PWD SoR 2022 rates are historical references and are not asserted to be the current applicable rates.
- Project BOQ quantities must be measured from approved drawings and verified site conditions; the schedule does not provide project-specific take-off quantities.
- Appendix B/C load estimates and Appendix F/G sizing rules are preliminary source-based helpers only. Full cable sizing, protection coordination, fault level, voltage drop, earthing, disconnection-time and statutory checks remain necessary.
- The custom rate build-up is an editable estimating model; percentage bases and tax treatment must follow the actual tender documents and applicable instructions.
