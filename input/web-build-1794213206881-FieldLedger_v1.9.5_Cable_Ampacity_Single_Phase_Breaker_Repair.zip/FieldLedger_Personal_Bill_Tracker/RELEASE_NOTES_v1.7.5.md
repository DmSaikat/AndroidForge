# FieldLedger v1.7.5 — Unlimited Engineer Assignments

- Added a reusable engineer directory with name, employee ID, designation, department and optional photograph.
- Each visit supports any number of assigned engineers, with exactly one Primary Engineer and remaining Additional Engineers.
- Existing single-engineer visit records are migrated in memory to a legacy primary assignment and remain compatible.
- New visit bills print all assigned engineers and their details.
- Primary engineer fields continue to populate the existing visit data fields for compatibility.
- Employee directory and visit assignments are stored in the existing local database and included in JSON backup/restore.

Static source checks only; APK/device testing remains required.
