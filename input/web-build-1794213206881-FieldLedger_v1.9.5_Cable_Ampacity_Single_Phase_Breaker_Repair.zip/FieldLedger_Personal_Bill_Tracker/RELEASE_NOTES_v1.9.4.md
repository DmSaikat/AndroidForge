# FieldLedger v1.9.4 — Clean BOQ & Tender Workspace

## BOQ & Tender layout
- Split the workspace into five focused areas: PWD Reference, Tender Draft, Quantity Take-off, Calculations, and Saved Drafts.
- Separate PWD reference browsing into Materials, Cables, Switchgear & Protection, Earthing & ECC, Substation & Generation, and Other E/M Works.
- Keep reference browsing separate from project BOQ drafting.
- Make project-specific/manual item entry collapsible to keep the main BOQ line table in focus.
- Make one-digit PWD subhead selection search correctly.
- Keep the existing strict pricing rule: only the 53 visually verified four-zone price entries are eligible for automatic addition; OCR-derived or uncertain prices remain blocked.

## Data and compatibility
- Preserve application ID `com.fieldledger.app`.
- Preserve local database key `fieldledger.personal.v2`.
- Preserve existing saved BOQ projects, lines, measurement records, rate analyses, employee data and visit data.
- Synchronize the web HTML with the Android WebView asset.
- Increment Android versionCode to 26 and versionName to 1.9.4.
- Bump service-worker cache key to `fieldledger-v7`.

## Validation scope
Static source checks only. AndroidForge APK compilation, native print/PDF behavior and physical-device interaction have not been tested.
