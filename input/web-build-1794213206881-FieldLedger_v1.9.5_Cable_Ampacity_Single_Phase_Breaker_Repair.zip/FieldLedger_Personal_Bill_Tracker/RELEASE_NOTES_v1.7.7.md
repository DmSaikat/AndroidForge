# FieldLedger v1.7.7 — Centralized Backup & Restore

- Removed Google Drive Backup and Restore actions from the global navigation menu.
- Removed the repeated Backup & Appearance panel from the Home/Overview screen.
- Added a single Backup & Restore panel inside the Measurement Tools page.
- Preserved the existing backup/export, restore/import functions and hidden file input.
- Dark-mode control remains in the Appearance section of the navigation menu.
- Existing local database, profile data, engineer directory, visits, expenses and historical settlement values are unchanged.

Static source and archive checks only; APK compilation and physical-device testing remain required.
