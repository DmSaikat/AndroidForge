# Code Review — v1.7.8

- The existing `profile` section and `menuGo('profile')` route were present in v1.7.7, but were accessible only from the side menu.
- Added an Overview panel with an explicit action to open the existing profile setup section.
- Added a summary derived from `db.profile` and `db.engineers`; it does not copy or migrate data.
- Updated both Android WebView and web HTML copies identically.
- Incremented Android versionCode to 17 and versionName to 1.7.8.
- No data schema changes.

Validation performed after packaging: HTML IDs, JavaScript syntax, HTML-copy equality and ZIP integrity. No APK/device test performed.
