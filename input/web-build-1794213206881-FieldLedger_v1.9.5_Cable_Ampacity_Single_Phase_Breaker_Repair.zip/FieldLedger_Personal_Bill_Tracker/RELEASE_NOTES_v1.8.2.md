# FieldLedger v1.8.2 — Half-A4 Expenditure Bill Layout

- Individual expenditure bills now occupy the top half of an A4 page (138 mm bill area plus 5 mm page margins).
- Added a compact print layout for the company header, engineer details, dates, project/work scope, expense table, amount in words, financial summary and signature lines.
- Removed ten default blank expense rows; actual expense items remain fully listed, with one blank row only when there are no expenses.
- Added automatic per-bill print scaling to fit unusually long engineer/expense/note content within the half-page area.
- Receipt thumbnails are reduced for print.
- Monthly/yearly summary exports are not modified.
- Android versionName 1.8.2, versionCode 21.

Static source checks only; actual print/PDF output and Android device printing must be tested.
