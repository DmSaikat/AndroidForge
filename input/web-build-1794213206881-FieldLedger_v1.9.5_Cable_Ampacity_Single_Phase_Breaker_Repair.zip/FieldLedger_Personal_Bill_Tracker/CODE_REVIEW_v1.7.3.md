# Code review – FieldLedger v1.7.3

- Home-screen Backup & Appearance panel makes backup/restore visible without opening the menu.
- Backup and restore functions remain available in the navigation drawer.
- Android native bridge retains `ACTION_CREATE_DOCUMENT` for save and `ACTION_OPEN_DOCUMENT` for restore.
- Web/browser fallback is correctly described as file download/upload, not direct Drive sync.
- Theme preference uses a separate localStorage key (`fieldledger.ui.theme.v1`); visit database key remains `fieldledger.personal.v2`.
- Android native status and navigation bars follow the stored theme.
- App ID unchanged; versionName 1.7.3, versionCode 13.

## Verification limits
- Static syntax and package checks are run during packaging.
- Physical Android save-picker/Drive-provider behaviour and APK compilation must still be tested on-device/through AndroidForge.
- Google Drive must be available as a document provider on the Android device; the app cannot silently upload files without user selection.
