# Code review v1.7.4

Changes are additive. Existing `fieldledger.personal.v2` database key is unchanged. Profile data is stored as `db.profile`; existing visits are not rewritten. JSON backup already serializes the full database object, so the profile is included automatically. New visit forms prefill employee details from the profile; older visit fields take precedence for their own bill. Image uploads are limited to 8 MB and resized to a maximum 600 px dimension as JPEG before storage.

Navigation no longer calls `window.scrollTo(0,0)` on every tab change, preserving scroll position during menu navigation.

Static checks are not equivalent to Android APK compilation or physical-device testing.
