# Load & Breaker Calculator — technical notes

## Load schedule
For each equipment row:
- Connected kW = quantity × unit kW
- Maximum-demand kW = quantity × unit kW × per-item demand factor
- If power basis is mechanical output, electrical input kW = maximum-demand kW / efficiency
- Demand kVA = electrical input kW / overall PF
- Single-phase design current IB = P × 1000 / (V × PF)
- Balanced three-phase design current IB = P × 1000 / (sqrt(3) × VLL × PF)

The calculation assumes a single overall PF and, for three-phase, balanced loading. Use electrical-input kW for mixed equipment unless all listed ratings are mechanical output ratings to which the same efficiency applies. This is steady-state current; the Power Division guideline gives a 1.65 multiplier for specified fluorescent/fan/small-inductive loads up to 1 kW when estimating current from watt ratings to account for PF and starting current. The tool does not calculate motor starting/inrush; apply the relevant local-guideline or manufacturer method separately.

## Cable capacity
BYA uses the published Power Division current-carrying-capacity table for copper 1-core cable and selected concealed/surface condition. Corrected capacity IZ = reference ampacity × Ktemp × Kgroup × Kthermal/installation × Kother.

NYY requires a catalogue ampacity entered by the user for the exact material, core count, insulation, installation and environmental conditions. It is unsafe to assign a single universal NYY ampacity.

## Preliminary breaker rating
The app searches a common rating series for the smallest candidate satisfying IB <= In <= IZ. Families are selected by the user (MCB/MCCB/ACB) because product family is not determined by current alone. This check is preliminary overload coordination, not a final device selection.

If both prospective fault current and actual device breaking capacity are supplied, the app compares them. Missing values are clearly reported as unchecked. It does not determine fault level, short-circuit withstand, trip-unit settings, I2, disconnection time, selectivity, earth-fault loop impedance or motor starting coordination.

## Bangladesh references
- Bangladesh Power Division, *Electrical Wiring in Residential Buildings & Specification of Electrical Cable, Fittings and Accessories*, guideline dated 15 Dec 2021: load schedule and diversity (3.2.2), 230 V single-phase / 400 V three-phase nominal supply, 1.65 multiplier for specified light/fan/small-inductive loads when estimating current from watt ratings, cable current-carrying capacity table for BYA, and cable type descriptions.
- BNBC 2020 Part 8, Chapter 1: minimum copper sizes for specified final circuits, 1.5 mm² minimum for final/sub-circuits and light/fan point wiring, and 2.5% voltage-drop limit to the farthest load point.
- IEC 60364-4-43:2023 overload protection and coordination requirements.
- Eaton Consulting Application Guide (2019): explanatory summary of IB <= In <= IZ and breaking-capacity checks; product standards/manufacturer data remain governing.

This tool is preliminary engineering support only. Verify the current adopted Bangladesh requirements, actual cable datasheet, manufacturer's protection data and site fault study before installation.
