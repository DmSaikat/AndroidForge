# FieldLedger v1.9.0 — BOQ & Tender

## New Measurement Tools module
- Added BOQ & Tender project workspace.
- Added project metadata: project title, client, tender/package reference, site, PWD rate zone, date and scope notes.
- Added searchable PWD SoR 2022 E/M schedule starter catalog with source PDF page references and four regional rate columns.
- Added manual/project-specific BOQ line creation and editable description, technical specification, unit, quantity and unit rate.
- Added optional overhead, profit, contingency and VAT/tax percentages, each calculated on the base BOQ subtotal and defaulted to zero.
- Added saved BOQ projects and print / Save as PDF output.
- Added reference notes from Appendices A, C, F, G, H and I.
- Added BOQ project data to local database and backup compatibility.

## Source and rate caution
The preloaded item rates are from the uploaded PWD Schedule of Rates 2022 for E/M Works. They are historical reference rates, not a statement of current rates. Verify the latest PWD schedule/circular, tender-specific requirements, addenda, drawings, applicable tax/VAT and contract conditions before submission. The catalog is a curated starter subset, not a full transcription of all 1,041 pages. No rates have been fabricated for other subheads; add those as manual items with verified rates.

## Selected preloaded source lines
- Wiring point items 1.1.1, 1.1.2, 1.2.1.1, 1.2.1.2, 1.2.1.3, 1.2.2.1, 1.3.1.1 — PDF pages 5–7.
- BYM/BYA submain/cable items 1.8.1.1–1.8.1.5, 1.8.2.1–1.8.2.2, 1.9.1.1–1.9.1.2 — PDF pages 12–13.
- HT switchgear item 2.1.1.1 — PDF pages 66–67.
- MS pole items 3.1.1–3.1.5 — PDF page 149.

## Existing data compatibility
- Preserved Android application ID `com.fieldledger.app`.
- Preserved localStorage key `fieldledger.personal.v2`.
- Added `boqProjects` collection to the existing data object and backup restore defaults/merge handling.
- Existing visits, expenses, employee/engineer records, office payments and backup/restore data are retained.

## Build metadata
- versionName: 1.9.0
- versionCode: 23
- This ZIP is AndroidForge source, not a compiled APK.
