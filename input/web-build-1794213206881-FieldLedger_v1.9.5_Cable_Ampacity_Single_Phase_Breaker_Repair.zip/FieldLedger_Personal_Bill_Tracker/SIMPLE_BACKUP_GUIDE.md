# FieldLedger v1.7.2 — Simple Google Drive backup guide

This version does not require Apps Script, a recovery code, an account inside FieldLedger, or backend setup. It uses Android's built-in document picker.

## First backup

1. Install FieldLedger v1.7.2 as an update over your existing FieldLedger app. Do not uninstall the previous app first.
2. Open FieldLedger and tap the menu.
3. Tap **Back up to Google Drive**.
4. In the Android save screen, choose **Google Drive** (it may be under the side menu or Browse locations).
5. Make sure the correct Google account is selected. Choose a folder such as `FieldLedger Backups`, then tap Save.
6. FieldLedger confirms that the backup file was created. The app cannot verify the destination provider, so make sure you chose Google Drive rather than Downloads or local storage.

## Restore on this or a replacement phone

1. Make sure Google Drive is installed and the same Google account is available on the phone.
2. Install FieldLedger.
3. Open the menu and tap **Restore from Google Drive**.
4. Browse to the saved `FieldLedger_Backup_YYYY-MM-DD.json` file and select it.
5. Type `MERGE` to add visits while keeping the newer version of records with matching IDs, or `REPLACE` to replace all current local records with the backup. Type `CANCEL` to stop.
6. Confirm the restored visit count.

## Important

- Create a fresh backup after important changes. This backup flow is manual; it does not automatically synchronize changes.
- A backup saved to the phone's Downloads folder is not protected if the phone is lost. Choose Google Drive to store it online.
- Keep the same Google account available to access the backup. This is a Google Drive requirement, not a FieldLedger account.
- Existing receipts stored as embedded images are included in the JSON. Legacy Drive receipt IDs remain links to their original Drive files; those image files are not copied into the JSON.
- Keep at least one recent backup before replacing phones or reinstalling the app.

## If you previously configured v1.7.1

This simple version no longer contacts the Apps Script gateway. It does not delete any old FieldLedger cloud vault or receipt files. Keep the old Drive folder until the new manual backup has been saved and tested. Old receipt links may still depend on the Google Drive account that owns those files.
