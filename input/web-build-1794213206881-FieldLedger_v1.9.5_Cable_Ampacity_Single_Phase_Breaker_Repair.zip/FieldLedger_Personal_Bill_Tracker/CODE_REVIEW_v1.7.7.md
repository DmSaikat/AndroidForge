# Code Review — v1.7.7

Scope:
- Backup and restore controls now appear only in Measurement Tools.
- The menu retains appearance controls but no longer contains backup actions/status.
- Home/Overview no longer contains the backup panel.
- The existing `exportLocalBackup()`, `restoreFromBackup()`, `importLocalBackup()` and `backupImport` file input are preserved.
- `menuSyncStatus` is retained by ID but relocated into Measurement Tools because the existing status updater looks it up by that ID.
- Local database key and data structures are unchanged.

Validation:
- Web and Android HTML copies are byte-for-byte identical.
- No duplicate static HTML IDs.
- Removed backup action labels checked outside Measurement Tools.
- ZIP integrity checked.
- JavaScript parser check and APK/device test are not claimed unless run separately.
