# Code Review — v1.8.0

Issue:
- The Measurement Tools selector and Backup & Restore landing panels remained visible alongside the selected calculator panel. This caused a vertically stacked appearance.

Fix:
- Added stable IDs to the two landing panels: `measurementBackupPanel` and `measureToolMenu`.
- `openMeasureTool(which)` hides both landing panels and all calculator panels, then reveals only the requested tool panel.
- The selected calculator panel receives `.screen-enter`.
- `backMeasureMenu()` hides all calculator panels and restores the two landing panels.

Validation:
- Android and web HTML copies updated identically.
- Static HTML IDs checked for duplicates.
- Inline JavaScript checked with Node parser.
- ZIP integrity checked.
- No APK compilation or physical-device test performed.
