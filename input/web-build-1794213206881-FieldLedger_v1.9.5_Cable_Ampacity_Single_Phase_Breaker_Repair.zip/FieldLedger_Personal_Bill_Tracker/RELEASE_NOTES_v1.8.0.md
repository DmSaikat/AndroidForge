# FieldLedger v1.8.0 — Measurement Tool Navigation Fix

- Selecting any Measurement Tools option now hides the Backup & Restore panel and the tool-selection menu.
- Only the selected calculator/reference screen remains visible.
- The existing Back to Tools action restores both landing panels.
- Added the existing screen-entry transition to the selected panel.
- No calculation formulas, backup functions, employee profiles, visit records or engineer assignments changed.
- Android versionName 1.8.0, versionCode 19.

Static source checks only; APK compilation and physical-device testing remain required.
