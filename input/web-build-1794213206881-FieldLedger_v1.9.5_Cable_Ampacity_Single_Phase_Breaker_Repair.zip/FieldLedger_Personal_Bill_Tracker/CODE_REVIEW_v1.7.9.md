# Code review — v1.7.9

Changes reviewed:
- Load schedule supports multiple rows and validates quantity, kW and demand factor.
- Connected load and maximum demand are calculated separately.
- Electrical input and mechanical output bases are distinguished; efficiency is applied only for mechanical-output basis.
- Single-phase current uses P/(V×PF); balanced three-phase current uses P/(sqrt(3)×VLL×PF).
- Cable reference ampacity is not treated as corrected Iz until correction factors are applied.
- NYY rating is manual catalogue input to avoid assuming core count/material/installation.
- Breaker rating candidates must satisfy IB <= In <= Iz.
- Short-circuit breaking capacity check is independent and only reported when both user-entered values are present.
- MCB/MCCB/ACB is user-selected; VCB is not part of the LV calculator.
- Existing records, profile, employee directory, backup and reports are untouched.

Known limits:
- Single overall PF and efficiency; three-phase loads assumed balanced.
- Demand factors are entered by user; no diversity schedule is imposed automatically.
- BYA ampacity table is a published reference, not a universal industrial cable table.
- Correction factors must be sourced from the actual cable standard/manufacturer.
- No full voltage-drop, fault-loop, adiabatic short-circuit, I2, selectivity or trip-curve calculation.
- Not a certified design output.

Static validation only; no Android APK build or device test claimed.
