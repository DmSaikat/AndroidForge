# FieldLedger v1.9.1 — BOQ quantity take-off and PWD calculation helpers

## Quantity take-off and BOQ completion
- Added a line-linked quantity measurement register for count, linear length, area, volume, cable/route length, labour person-days and direct measured quantities.
- Stores calculation formula, result, measurement method, drawing/location reference and remarks against each BOQ line.
- Measurement totals are not silently applied; the estimator must explicitly use **Apply total to selected BOQ line**.
- Quantity measurement records are retained with the BOQ project and included in the printed estimate.

## PWD-source calculation aids
- Added PWD SoR 2022 Appendix B minimum load-density estimator by occupancy and A.C./non-A.C. status, with separate process/machinery load input.
- Added Appendix C fixture wattage references and its 1.65 current-sizing note, applied only to the qualifying load portion entered by the estimator.
- Added preliminary single/three-phase current relationships, Appendix F changeover minimum rating (1.25 × incoming breaker rating), and Appendix G copper ECC sizing rules.
- Added Appendix H four-zone electrical labour daily-rate calculator and an action to add the calculated person-day amount to the BOQ.
- Added Appendix A/D/E planning references and Annexure I.5 cable ampacity-table caution.

## Project-specific rate analysis
- Added per-BOQ-unit rate build-up for material, material wastage, labour, plant/equipment, transport/testing/other direct cost, overhead and profit.
- A PWD schedule-priced item requires confirmation before applying a custom build-up.
- Editing the unit rate manually clears the previously attached build-up so the printed rate analysis does not misrepresent the final rate.
- Printed estimate includes both the quantity take-off register and analyzed unit-rate build-up register when available.

## Compatibility and limitations
- Preserved Android application ID `com.fieldledger.app` and localStorage key `fieldledger.personal.v2`.
- BOQ measurements and rate analyses are stored inside the BOQ project object and remain included in existing backup/restore data.
- Preloaded PWD schedule lines remain a curated, source-checked starter set; this release does not transcribe all line items from the 1,041-page PDF.
- PWD SoR 2022 regional rates are dated references. Confirm the current applicable schedule, tender addenda, approved drawings, specifications, procurement rules and tax/VAT treatment before submission.

Source: user-provided PWD Schedule of Rates 2022 for E/M Works. Key calculation references include Annexure I.5 (PDF p.65) and Appendices A–I (PDF pp.894–900). Quantity take-off and custom rate build-up models are estimating helpers; project quantities and tender pricing bases must be established from project records and tender requirements.

Build metadata: versionName `1.9.1`; versionCode `23`. This package is AndroidForge source, not a compiled APK.
