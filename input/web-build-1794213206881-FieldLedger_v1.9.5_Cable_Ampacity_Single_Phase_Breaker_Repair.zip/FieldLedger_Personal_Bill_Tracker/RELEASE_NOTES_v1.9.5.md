# FieldLedger v1.9.5 — cable ampacity matrix & single-phase breaker repair

## Cable & Breaker Reference
- Replaced the BYA-only lookup with the PWD SoR 2022 Annexure I.5 current-carrying-capacity matrix for BYA, BYM, BYFYE, NYY, NYFGbY, NYSEYFGbY and XLPE.
- Added core-count and installation-condition selection (concealed/surface or underground/air as printed in the schedule).
- Added a full cross-section ampacity table for the selected cable family/core count, with missing source cells shown as dashes rather than filled with a generic 20 A value.
- Added explicit reference ampacity, manual manufacturer-datasheet override for blank source cells, and correction-factor calculation to corrected Iz.
- Added preliminary breaker coordination using IB ≤ In ≤ Iz, with optional fault-current / breaking-capacity input comparison.
- Single-phase mode shows 1P, 1P+N and 2P pole arrangements and common MCB current ratings; three-phase mode shows 3P / 4P.
- The load-breaker calculator now shares the same PWD cable-type/core-count lookup and single-phase pole options.

## Source fidelity and cautions
- Ratings are transcribed from the supplied PWD Schedule of Rates 2022 for E/M Works, Annexure I.5, PDF page 65 (printed page 61).
- Blank / dash cells remain unavailable; they are not interpolated. A datasheet value is required for those combinations.
- The BYM 1.0 mm² 2-core concealed entry is not legible enough in the scan and is intentionally withheld. The BYM 6 mm² 3/4-core surface value and NYSEYFGbY 240 mm² values are shown as printed but flagged for verification because they appear anomalous.
- Cable ampacity is not a final design rating. Users must apply actual installation correction factors and verify manufacturer data, protective-device characteristics, fault level, disconnection time, short-circuit withstand, selectivity and starting current.

## Compatibility
- Android applicationId remains `com.fieldledger.app`.
- Local database key remains `fieldledger.personal.v2`; existing visit, expense and BOQ data structures are untouched.
- Web and Android WebView HTML are synchronized.
- Android versionName: 1.9.5; versionCode: 27.

## Validation performed
- JavaScript syntax check passed.
- HTML parse check passed; no duplicate element IDs found.
- Functional lookup tests passed for BYA, BYM, NYY, NYFGbY and XLPE sample combinations; missing/ambiguous source cell returned unavailable rather than a guessed value.
- Single-phase 230 V MCB screening test passed (1.5 mm² BYA surface entry: 20 A reference ampacity; 10.5 A load produced a 13 A candidate under K=1 assumptions).
- Web and Android HTML files compared identical.
- Android APK build / physical-device UI test was not run in this environment.
