# FieldLedger v1.9.3 — strict PWD pricing audit and material reference library

## Strict pricing policy
- Disabled every OCR-extracted and OCR-reconstructed price from the previous PDF item-row parser.
- Removed raw OCR rate cells from structured item candidates.
- Added a strict allow-list: only item rows manually transcribed from the rendered original PDF scan are eligible for automatic price transfer into a BOQ.
- Search-only rows show item/description/unit and PDF page reference, but no price and no Add Price action.
- Raw OCR rate-table page text is suppressed in the page viewer and results, including 845 pages detected by rate headers, parsed item rows or repeated monetary-looking OCR cells. Technical/specification pages remain viewable.
- BOQ add function rejects any row without `rateVerified=true`, `rateStatus=visually-verified-from-source-scan` and four positive zone rates.

## Visually verified price set
- 53 item rows manually transcribed from PDF scan pages 47, 48, 155, 156, 165 and 343.
- Groups include 3-core and 4-core NYY loop cables; copper refrigerant tubes and copper branch joint; aluminium ASC and ACSR overhead conductors; SPMCB and TPMCB entries.
- Each enabled rate retains the source PDF page and four original regional columns.

## Material and technical data
- Added a structured, visually transcribed 8-row HT XLPE cable dimensions/mechanical/electrical table from PDF page 53, with insulation/armour/sheath thickness, cable diameter, approximate weight, DC resistance, current ratings in ground/air at 20°C, capacitance and inductance.
- Added searchable material topics for Copper (Cu), Aluminium (Al), cable types/construction, HT XLPE electrical/mechanical data, earthing/ECC, copper busbars and switchgear.
- Included references to the relevant source pages and manually transcribed technical details from the scans (including HT XLPE cable table data, cable classes, and ECC relationship).
- Added aliases so searches such as `Cu`, `Al`, `ASC`, `ACSR`, `BYA`, `BYM`, `NYY`, `ECC` find relevant source information.

## Preserved
- Application ID `com.fieldledger.app`.
- Local storage key `fieldledger.personal.v2`.
- Existing BOQ, measurement take-off, rate analysis, reports and backup/restore structure.
- Android/web assets remain in sync.

## Accuracy limitation
- Only the 53 listed prices are enabled for automatic BOQ pricing after visual checking against the original PDF scans.
- Other prices remain intentionally unavailable until individually checked. This is not a full visual audit of every PWD price table in all 1,041 pages.
- Technical data shown from scanned tables is explicitly source-referenced. It is not a substitute for project-specific engineering verification.
- PWD SoR 2022 is a historical schedule; confirm the applicable tender schedule and amendments before submission.

## Tests
- To be completed by release packaging audit; AndroidForge APK build and physical-device testing are not performed in this source-package pass.
