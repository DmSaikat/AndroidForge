# Code review — FieldLedger v1.7.2

## Change summary

- Removed the Apps Script endpoint, Recovery Code, automated cloud sync and network request bridge.
- Replaced the menu with two clear actions: Back up to Google Drive and Restore from Google Drive.
- Backup uses Android `ACTION_CREATE_DOCUMENT` with `application/json`, allowing the user to choose Google Drive in the Android document picker.
- Restore uses Android `ACTION_OPEN_DOCUMENT` for JSON files via the WebView file chooser.
- Kept the local database key `fieldledger.personal.v2` and Android application ID `com.fieldledger.app`.
- Bumped Android version to 1.7.2 / versionCode 12.

## Restore safety

- The import validates JSON structure and visit IDs before writing.
- MERGE preserves visits missing from the backup and selects the newer record by `updatedAt` for matching IDs.
- REPLACE is an explicit typed choice; CANCEL does not modify data.
- The previous in-memory database is restored if local persistence fails.

## Limitations

- This is a manual file backup/restore workflow, not automatic synchronization.
- The app cannot confirm that the user selected Google Drive rather than local device storage.
- Google Drive access depends on the Android Drive document provider and the user's Google account being available on the device.
- Legacy receipt file IDs are retained but the corresponding images are not downloaded into the JSON backup.
- APK build and physical-device testing have not been performed in this source package.
