# Release notes — v1.7.2

- Replaced complicated login-less Apps Script setup with simple manual backup and restore using Android's file picker.
- User can save the JSON backup directly to Google Drive by choosing Drive in the Save screen.
- User can restore a backup by selecting the JSON file from Google Drive.
- Added safe MERGE / REPLACE / CANCEL restore modes.
- Preserved the existing app ID, local database key, and FieldLedger features.
- No automatic cloud synchronization; create backups manually after important changes.
