# FieldLedger v1.8.3 — Return Home After Saving Bill Items

- After adding one or more expenditure items, the app now returns to the Home / Overview page once local storage confirms the save succeeded.
- The visit and all newly added items are persisted before navigation.
- A completion toast confirms the number of saved items.
- If receipt reading, input validation or local persistence fails, the app stays in the current workflow and does not navigate away.
- The expense-entry form resets only after a successful save.
- The app keeps the existing visit, expense, employee profile, engineer directory, backup and half-A4 bill logic.
- Android versionName 1.8.3, versionCode 22.

Static source checks only; APK compilation and physical-device testing remain required.
