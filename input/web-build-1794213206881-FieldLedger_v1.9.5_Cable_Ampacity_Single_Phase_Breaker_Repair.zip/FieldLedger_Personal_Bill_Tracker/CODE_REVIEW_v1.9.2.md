# Historical v1.9.2 review — superseded

The original v1.9.2 parser exposed 294 provisional OCR rate candidates. This was not sufficiently safe for tender pricing. These candidates have all been disabled and removed from automatic BOQ pricing in v1.9.3. Use only the visually verified rate allow-list in `PWD_PRICE_VERIFICATION_AUDIT_v1.9.3.md`.
