# PWD price verification allow-list — FieldLedger v1.9.3

**Rule:** a price is eligible only if its item, unit and all four zone values were visually transcribed from the rendered original PDF page. All OCR-only values are withheld.

| Source PDF page | Item family | Number of enabled rows | Verification |
|---:|---|---:|---|
| 47–48 | NYY loop cables, 4-core and 3-core | 28 | Original page scans visually checked |
| 343 | Copper refrigerant tubes and RefNet/branch joint | 10 | Original page scan visually checked |
| 155–156 | Aluminium ASC and ACSR overhead conductors | 12 | Original page scans visually checked |
| 165 | SPMCB and TPMCB breakers | 3 | Original page scan visually checked |
| **Total** | | **53** | **Enabled for BOQ pricing** |

The application hides OCR-derived prices from the searchable item candidate results and suppresses raw OCR text on pages containing rate tables. Unverified item descriptions and technical/reference pages remain searchable.

The material reference library also includes Cu, Al, cable families, earthing/ECC, switchgear/busbars and a structured 8-row HT XLPE technical table transcribed from PDF page 53. The more difficult Annexure I.5 cable ampacity cells on PDF page 65 are kept as a page reference only; no numeric ampacity values are copied into calculations.

The enabled rates are PWD SoR 2022 values, not a statement of current market prices. See each BOQ item's source PDF page and verify the applicable tender schedule before submission.

## Material information indexed
- Copper (Cu): 99.99% annealed stranded copper cable conductor requirements, copper metallic screen, copper tubes and pure copper branch joints (PDF pages 50–54, 343).
- Aluminium (Al): ASC insulated stranded conductor, ACSR bare conductor, armour material and bend-radius references (PDF pages 52, 55, 155–156).
- Cable specifications: BYA, BYM, BYFYE, NYY and HT XLPE; insulation test voltages; 3-core HT XLPE mechanical/electrical table; bending-radius and trench guidance; Annexure I.5 cable ampacity source page (PDF pages 47–55, 65).
- Earthing/ECC, earth electrodes and copper busbar/switchgear source references (PDF pages 66, 93, 121, 126–128, 165, 898).

The material technical index is source information, not automatically a project design. Numerical cells in scanned tables that have not been visually transcribed remain source-page-only.
