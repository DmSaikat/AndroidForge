# Code review — v1.9.5

## Scope reviewed
- PWD Annexure I.5 cable current ratings for seven cable families.
- Single-phase pole and standard MCB rating selection in Cable & Breaker Reference and Load & Breaker Calculator.

## Checks
- Source table includes BYA, BYM, BYFYE, NYY, NYFGbY, NYSEYFGbY and XLPE with construction/core and installation-specific ampacity columns.
- No generic 20 A fallback remains in the wire-rating field; design load current defaults blank in Cable & Breaker Reference.
- Empty source cells remain null and are rendered as dashes; datasheet override is explicit.
- Corrected ampacity is reference ampacity multiplied by entered ambient, grouping and installation factors.
- Preliminary breaker candidates satisfy IB ≤ In ≤ Iz; 1-phase exposes 1P, 1P+N and 2P and uses a common MCB rating series.
- Optional fault and device breaking-capacity inputs are compared only when both values are supplied.
- No final-protection-design claim is made; I2, trip curves, short-circuit withstand, disconnection time, earth-fault loop and selectivity remain field/design checks.

## Known source caveats
- BYM, 1.0 mm², 2-core concealed ampacity is withheld due unclear scan digit.
- BYM, 6 mm², 3/4-core surface and NYSEYFGbY, 240 mm² entries are transcribed as printed but flagged for independent verification.

## Not performed
- Android Gradle APK build, AndroidForge build, emulator test and physical-device test.
