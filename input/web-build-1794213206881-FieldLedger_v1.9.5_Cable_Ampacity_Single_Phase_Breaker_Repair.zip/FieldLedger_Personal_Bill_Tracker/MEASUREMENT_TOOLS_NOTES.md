# Measurement Tools addition

Added a new bottom-navigation tab: Measurement Tools. It opens a menu with:
- Basic calculator
- Unit converter (length, area, volume, mass, pressure, power, apparent power, energy, force/weight, speed, flow, temperature, torque, frequency, current, voltage, resistance, capacitance, inductance, density)
- Electrical calculator (single/three-phase load current, kW to kVA, HP to kW, three-phase transformer full-load current)
- Cable and breaker reference (BYA copper concealed/surface ampacity from the Bangladesh Power Division 15 Dec 2021 guideline; approximate resistive voltage-drop screening; breaker coordination reminders)

## Standards and limitations
- BNBC 2020 Part 8: 2.5% voltage-drop limit to the farthest load point; minimum copper conductor sizes for specified final circuits; cable sizing must account for thermal limits and protection.
- Bangladesh Power Division guideline dated 15 Dec 2021: BYA copper current ratings are shown for concealed (C) and surface (S) installations as tabulated.
- NYY ampacity is deliberately not guessed from an ambiguous/insufficiently identified table row. The interface directs the user to the exact manufacturer's datasheet for the selected NYY construction and installation.
- The voltage-drop figure is explicitly labelled an approximate resistive estimate using copper resistivity at 20°C and neglecting reactance/temperature rise. It is not a certified design calculation.
- No automatic VCB selection. MCB/MCCB device family is explained, not automatically assigned solely by current rating. Final selection requires fault level, breaking capacity, disconnection time, correction factors and coordination checks.

## Validation
- JavaScript syntax checked with Node.js `node --check`.
- ZIP integrity checked after packaging.
- No Android APK build or device testing performed in this environment.


## v1.9.5 cable current-rating source update
The cable selector now uses PWD SoR 2022 for E/M Works, Annexure I.5 (PDF page 65 / printed page 61), across BYA, BYM, BYFYE, NYY, NYFGbY, NYSEYFGbY and XLPE. Core count and installation columns must match the selection. Dashes or illegible cells are treated as unavailable; use an exact manufacturer datasheet value rather than extrapolating. The reference rating is reduced by user-entered correction factors to estimate corrected Iz. The single-phase breaker check uses 230 V and exposes 1P, 1P+N and 2P arrangements with common MCB ratings.
