# FieldLedger v1.7.4 — Navigation and employee profile

- Fixed menu section navigation so switching sections preserves the current scroll position instead of forcing the page to the top.
- Added an Employee Profile section for name, employee ID, designation, department and profile photo.
- Profile details are stored in the existing local database and included in JSON backups.
- New visits prefill employee fields from the saved profile; visit-specific values can still be edited.
- Individual expenditure bills use saved profile details when a visit field is blank and can include the employee photo.
- Preserved the existing application ID, database key, visit records, backup/restore, dark mode and Measurement Tools.
