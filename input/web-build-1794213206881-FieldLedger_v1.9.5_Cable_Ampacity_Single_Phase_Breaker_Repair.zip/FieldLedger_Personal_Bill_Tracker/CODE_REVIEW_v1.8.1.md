# Code Review — v1.8.1

Issue:
- Dashboard header and four summary cards were direct children of `<main>`, outside any route-controlled `<section>`. The `tab()` function only toggles `main > section`, leaving those dashboard elements visible on every page.

Fix:
- Moved the dashboard header / New Site Visit shortcut and summary cards into `<section id="overview">`.
- Kept the `.tabs` navigation strip outside the sections intentionally, so navigation remains available across routes.
- No element IDs or data bindings changed.

Validation:
- Android and web HTML copies updated identically.
- No duplicate static HTML IDs.
- Inline JS passes Node syntax check.
- ZIP integrity passes.
- No Android APK compilation or device test performed.
