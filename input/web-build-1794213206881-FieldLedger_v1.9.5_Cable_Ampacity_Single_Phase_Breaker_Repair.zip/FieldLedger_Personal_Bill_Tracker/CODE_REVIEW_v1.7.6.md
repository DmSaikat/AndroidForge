# Code Review — v1.7.6

Changes:
- Removed settlement UI controls from the visit form.
- Removed form initialization/edit/save DOM references to those controls to prevent null-element errors.
- Existing settlement properties are intentionally not deleted from visit objects; historical financial data and calculations remain available.
- Version updated to 1.7.6 / versionCode 15.

Validation:
- Both web and Android WebView HTML copies updated identically.
- HTML IDs checked for duplicates.
- APK compilation and physical-device testing not performed.
