# FieldLedger Android project

Clean Java-only Android WebView project for the FieldLedger field-visit advance and expense tracker.

- Android package: `com.fieldledger.app`
- Main activity: `app/src/main/java/com/fieldledger/app/MainActivity.java`
- App UI: `app/src/main/assets/index.html`
- No Kotlin source files are included.
- Gradle Android plugin: 8.6.1; compile SDK 35; minimum SDK 23.

Build with AndroidForge using Android (APK), variant `debug` or `auto`.

## Prototype limitation
The app stores data locally in WebView local storage. It does not provide shared engineer/office accounts, cloud synchronization, or server-side approvals.


## Expenditure bill printing and company settings
Open **App settings** from the navigation menu to edit the printed company name, bill title, address, phone, fax, employee ID, designation, department, and upload a company logo. The **Print expenditure bill** action is available in each visit's detail screen. It generates an A4 print layout from the visit's expense entries and opens the device/browser print dialog. Company print settings are currently stored locally on each device; they are not synchronized to Firebase in this build. Allow pop-ups for the print window.
