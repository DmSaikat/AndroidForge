import { initializeApp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-app.js';
import { getAuth, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-auth.js';
import { getFirestore, collection, doc, setDoc, onSnapshot, enableIndexedDbPersistence, serverTimestamp } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js';
import { getStorage, ref, uploadString, getDownloadURL } from 'https://www.gstatic.com/firebasejs/11.10.0/firebase-storage.js';
import { firebaseConfig } from './firebase-config.js';
const gate=document.getElementById('authGate'), msg=document.getElementById('authMessage'), state=document.getElementById('cloudState'), signout=document.getElementById('signOutBtn');
let auth,dbCloud,storage,user=null,unsubscribe=null,started=false;
const configured=firebaseConfig.apiKey && firebaseConfig.apiKey!=='PASTE_API_KEY_HERE' && firebaseConfig.projectId!=='YOUR_PROJECT_ID';
function message(t){msg.textContent=t}
function cloudStatus(t){state.textContent='Cloud: '+t}
function localDB(){try{return JSON.parse(localStorage.getItem('fieldledger.v1')||'{"visits":[]}')}catch{return {visits:[]}}}
function localSave(data){localStorage.setItem('fieldledger.v1',JSON.stringify(data));if(window.render)window.render()}
async function uploadReceiptData(data,uid,visitId,expenseIndex,receiptIndex){if(typeof data!=='string'||!data.startsWith('data:image/'))return data;const path=`users/${uid}/receipts/${visitId}/${expenseIndex}_${receiptIndex}_${Date.now()}.jpg`;const r=ref(storage,path);await uploadString(r,data,'data_url',{contentType:'image/jpeg'});return await getDownloadURL(r)}
async function cloudSafeVisit(v){const copy=JSON.parse(JSON.stringify(v));for(let i=0;i<(copy.expenses||[]).length;i++){const arr=copy.expenses[i].receipts||[];for(let j=0;j<arr.length;j++){if(arr[j]?.startsWith?.('data:image/')){try{arr[j]=await uploadReceiptData(arr[j],user.uid,v.id,i,j)}catch(e){console.warn('Receipt upload queued locally',e);}}}}return copy}
async function writeVisit(v){if(!user)return;const copy=await cloudSafeVisit(v);await setDoc(doc(dbCloud,'users',user.uid,'visits',v.id),{...copy,updatedAt:serverTimestamp()},{merge:true});
 // Replace uploaded local data URLs with their cloud URLs once the document write succeeds.
 const local=localDB(),idx=local.visits.findIndex(x=>x.id===v.id);if(idx>=0){local.visits[idx]=copy;localSave(local)}
}
async function saveAll(data){if(!user)return;try{cloudStatus(navigator.onLine?'syncing…':'offline · queued');if(!navigator.onLine)return;for(const v of (data.visits||[]))await writeVisit(v);cloudStatus('synced')}catch(e){console.error(e);cloudStatus('sync pending')}}
function subscribe(){if(unsubscribe)unsubscribe();const col=collection(dbCloud,'users',user.uid,'visits');unsubscribe=onSnapshot(col,snap=>{const incoming=snap.docs.map(d=>d.data());const current=localDB();const map=new Map(incoming.map(v=>[v.id,v]));for(const v of current.visits){if(!map.has(v.id))map.set(v.id,v)}const merged={visits:[...map.values()]};localSave(merged);cloudStatus('synced')},err=>{console.error(err);cloudStatus('sync pending')});}
function showApp(){gate.style.display='none';signout.style.display='inline-block';document.querySelector('main').style.display='block'}
function showLogin(){gate.style.display='grid';signout.style.display='none';document.querySelector('main').style.display='none'}
if(!configured){showLogin();message('Firebase setup is incomplete. Add your Firebase project values to firebase-config.js, then rebuild the APK.');cloudStatus('setup required')}
else {try{const app=initializeApp(firebaseConfig);auth=getAuth(app);dbCloud=getFirestore(app);storage=getStorage(app);enableIndexedDbPersistence(dbCloud).catch(e=>console.warn('Firestore cache:',e.code));onAuthStateChanged(auth,async u=>{user=u;if(u){showApp();message('');cloudStatus('syncing…');subscribe();await saveAll(localDB())}else{if(unsubscribe)unsubscribe();showLogin();cloudStatus('signed out')}})}catch(e){showLogin();message('Firebase initialization failed: '+e.message);cloudStatus('error')}}
document.getElementById('loginForm').addEventListener('submit',async e=>{e.preventDefault();if(!auth){message('Complete Firebase configuration first.');return}try{message('Signing in…');await signInWithEmailAndPassword(auth,document.getElementById('loginEmail').value.trim(),document.getElementById('loginPassword').value)}catch(err){message(err.message)}});
document.getElementById('createAccountBtn').addEventListener('click',async()=>{if(!auth){message('Complete Firebase configuration first.');return}try{message('Creating engineer account…');await createUserWithEmailAndPassword(auth,document.getElementById('loginEmail').value.trim(),document.getElementById('loginPassword').value)}catch(err){message(err.message)}});
window.addEventListener('online',()=>{if(user)saveAll(localDB())});
window.FieldLedgerCloud={saveAll,signOut:()=>signOut(auth)};
