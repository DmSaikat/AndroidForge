package com.fieldledger.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        webView = new WebView(this);
        WebSettings s = webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true);
        webView.setWebChromeClient(new WebChromeClient()); webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new SheetsBridge(), "FieldLedgerBridge");
        setContentView(webView); webView.loadUrl("file:///android_asset/index.html");
    }
    private class SheetsBridge {
        @JavascriptInterface public void sync(String raw) {
            executor.execute(() -> {
                boolean ok=false; String message="Network error";
                HttpURLConnection c=null;
                try {
                    JSONObject obj=new JSONObject(raw); String endpoint=obj.getString("url");
                    URL u=new URL(endpoint); c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setDoOutput(true);
                    c.setConnectTimeout(20000); c.setReadTimeout(60000); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                    byte[] bytes=raw.replace("\"url\":\""+endpoint+"\",", "").getBytes(StandardCharsets.UTF_8);
                    try(OutputStream os=c.getOutputStream()){os.write(bytes);} int code=c.getResponseCode(); ok=(code>=200&&code<400); message="HTTP "+code;
                } catch(Exception e){ message=e.getMessage()==null?"Sync failed":e.getMessage(); }
                finally { if(c!=null)c.disconnect(); }
                final boolean success=ok; final String msg=message.replace("\\","\\\\").replace("'","\\'").replace("\n"," ");
                runOnUiThread(() -> webView.evaluateJavascript("window.onFieldLedgerSyncResult("+success+",'"+msg+"')", null));
            });
        }
    }
    @Override public void onBackPressed(){ if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed(); }
}
