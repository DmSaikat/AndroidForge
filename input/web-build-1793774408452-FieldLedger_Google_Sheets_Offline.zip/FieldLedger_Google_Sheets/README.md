# FieldLedger — Google Sheets edition

Engineer-only, offline-first Android app. Local records remain in WebView localStorage. When online and configured, the Android bridge posts the full visit dataset to a Google Apps Script Web App, which upserts visit rows in Google Sheets and moves receipt images into a private Drive folder.

## One-time Google setup
1. Create a Google Sheet named `FieldLedger Records`; copy its ID from the URL.
2. Create a Drive folder named `FieldLedger Receipts`; copy its folder ID.
3. Open https://script.google.com/ and create a project. Replace its Code.gs with `google-apps-script/Code.gs`.
4. In Code.gs, fill `SPREADSHEET_ID`, `DRIVE_FOLDER_ID`, and `API_KEY` (use a long random value).
5. In `app/src/main/assets/index.html`, replace `API_KEY` with the exact same value.
6. Deploy > New deployment > Web app. Execute as **Me**. Set access to **Anyone**. Deploy and copy the Web app URL ending `/exec`.
7. Build/install APK. In FieldLedger tap **Connect Sheets**, paste the `/exec` URL.

## Sync behavior and limitations
- Data is saved locally immediately, including while offline.
- When internet is available, app sends the complete local visit dataset; Apps Script upserts rows by Visit ID.
- Receipt data URLs are uploaded to Drive and replaced in the JSON stored in the sheet by Drive file IDs.
- This is a single-engineer prototype. The Web App endpoint is callable by anyone who has both the URL and API key. The key is embedded in the APK and is not a strong security boundary. Do not store highly sensitive personal or financial data this way.
- Drive receipt file IDs are stored in the record JSON; the current UI does not yet render Drive receipt IDs as downloadable links.
- Automatic sync is triggered after edits and when connectivity returns; keep app open briefly after reconnecting. No conflict resolution or multi-device merge is implemented.
- The current native sync bridge is Android-only; the browser/PWA view remains local-only.
