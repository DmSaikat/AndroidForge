FIELDLEDGER WEB APP
Run locally: open index.html in a modern browser. For PWA install/offline support, host the web folder over HTTPS (or localhost) and choose Install App in the browser.
Records are stored in browser localStorage on that device. This prototype has no shared cloud database, authentication, server-side approval or cross-device sync. Do not use it for confidential/company financial records until a secure backend, user accounts, backups and audit controls are added.
