# FieldLedger — Field Visit Advance & Expense Manager

A first working prototype for the engineer's field-visit workflow.

## Included
- Responsive web dashboard and Android WebView project
- Factory/client, location, engineer, visit date and work-scope records
- Advance amount, payment date/method and reference
- Itemized expense entries with categories and dates
- Receipt photo attachment (stored as image data in the local browser/app storage)
- Automatic advance / expense / balance calculation
- Submit-for-approval, office approve/reject, correction and settlement flow
- Visit list and consolidated overview

## Run the web app
Open `web/index.html` in a modern browser. For installable PWA/offline caching, serve the `web` directory over HTTPS or localhost.

## Build Android APK
1. Open the `android` folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install Android SDK 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. This produces a debug APK for testing.

## Important prototype limitations
This build stores records locally on each device using localStorage. It does not yet provide shared engineer/office data, real authentication, cloud backup, server-side approvals, notifications, or tamper-resistant audit logs. The Office Review tab demonstrates the approval workflow on the same device. For actual company deployment, add a secure backend (e.g. Firebase/Supabase/custom API), separate engineer and office accounts/roles, access controls, encrypted transport, backups and immutable approval history. The office dashboard and engineer app must connect to the same backend for real cross-device approval.


## Premium UI update
The interface has been refined with a consistent navy/blue/white palette, improved typography, rounded financial cards, clearer status chips, refined forms and responsive mobile spacing. The Android WebView asset and web app use the same updated UI.


## Manual-entry fields
- Advance amount and expense amount are direct numeric-entry fields; users can type any amount.
- Custom work scope lets the engineer enter a scope not covered by the preset list.
- Custom expense category lets the engineer enter a category not covered by the preset list.
- Existing description and notes fields remain free text.
