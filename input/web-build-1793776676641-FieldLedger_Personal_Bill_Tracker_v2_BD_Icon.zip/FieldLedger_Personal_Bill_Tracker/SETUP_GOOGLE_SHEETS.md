# FieldLedger — personal bill tracker (Google Sheets edition)

FieldLedger is an engineer's personal record book for factory visits, advances and expenditure. There is no personal submission, approval or review workflow.

## Included
- Personal visit records with editable visit details.
- Advance and visit-level information.
- Multiple bill items can be entered in one batch; each item has only a description and amount. Expense category and expense date fields are intentionally omitted.
- Each bill item can be edited or deleted later.
- Data is stored locally first. When Google Sheets is configured and the device is online, the full visit dataset is sent to the connected Apps Script endpoint. A pending local dataset is retried when connectivity returns.
- Optional receipt photos can be attached to a batch of bill items and stored in the configured Drive folder.

## Google Sheets setup
1. Create a Google Sheet named `FieldLedger Records`; copy its ID from the URL.
2. Create a Drive folder named `FieldLedger Receipts`; copy its folder ID.
3. Open https://script.google.com/ and create a project. Replace its `Code.gs` with `google-apps-script/Code.gs`.
4. In `Code.gs`, fill `SPREADSHEET_ID`, `DRIVE_FOLDER_ID`, and `API_KEY` (use a long random value).
5. Deploy as a Web app, execute as **Me**, and set access to **Anyone**. Copy the deployment URL ending `/exec`.
6. In the Android app, open the menu → **Connect Google Sheets**. Enter the `/exec` URL and the same API key.
7. The app writes to local storage immediately. It syncs the complete local dataset after changes and when the device reconnects. Keep the app open briefly after reconnecting.

## Important limitations
- This is designed for one person's own tracking, not personal submission or multi-user approval.
- The API key is stored on the device and sent to Apps Script. Anyone who obtains both the deployment URL and key could access the endpoint. This is a convenience-grade personal workflow, not a strong security boundary. Do not store highly sensitive information.
- Android synchronization uses the native bridge. The browser/PWA version remains local-only.
- No multi-device conflict resolution is implemented.
- The Web App deployment and spreadsheet/folder IDs must be configured before cloud sync can work. The source package is not a compiled APK.
