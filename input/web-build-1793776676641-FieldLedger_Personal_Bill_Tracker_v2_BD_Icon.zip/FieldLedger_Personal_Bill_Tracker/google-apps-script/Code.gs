// FieldLedger Personal Bill Tracker — Google Sheets + Drive backend
// Deploy as Web app: Execute as Me; access Anyone. Protect this endpoint URL and rotate it if exposed.
const SPREADSHEET_ID = 'PASTE_SPREADSHEET_ID_HERE';
const DRIVE_FOLDER_ID = 'PASTE_DRIVE_FOLDER_ID_HERE';
const API_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_SECRET';
function doPost(e) {
  try {
    const body = JSON.parse(e.postData.contents || '{}');
    if (body.apiKey !== API_KEY) return out({ok:false,error:'Unauthorized'});
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sh = ss.getSheetByName('Visits');
    if (!sh) { sh=ss.insertSheet('Visits'); sh.appendRow(['Visit ID','Last Synced','Factory','Engineer','Visit Date','Advance','Expenses Total','Work Scope','Record JSON']); }
    const visits = (body.data && body.data.visits) || [];
    visits.forEach(v => {
      // Keep receipt images in Drive instead of storing large base64 strings in cells.
      (v.expenses || []).forEach((exp,ei) => {
        exp.receipts = (exp.receipts || []).map((r,i) => {
          if (typeof r !== 'string' || !r.startsWith('data:image/')) return r;
          const parts=r.split(','); const mime=(parts[0].match(/data:(.*);base64/)||[])[1]||'image/jpeg';
          const name='FieldLedger_'+v.id+'_expense'+ei+'_receipt'+i;
          const folder=DriveApp.getFolderById(DRIVE_FOLDER_ID); const matches=folder.getFilesByName(name);
          if(matches.hasNext()) return matches.next().getId();
          const blob=Utilities.newBlob(Utilities.base64Decode(parts[1]),mime,name);
          return folder.createFile(blob).getId();
        });
      });
      const row=[v.id,new Date(),v.factory||'',v.engineer||'',v.visitDate||'',Number(v.advance||0),(v.expenses||[]).reduce((a,x)=>a+Number(x.amount||0),0),v.scope||'',JSON.stringify(v)];
      const last=sh.getLastRow(); let found=0;
      if(last>1){const ids=sh.getRange(2,1,last-1,1).getValues(); for(let i=0;i<ids.length;i++) if(String(ids[i][0])===String(v.id)){found=i+2;break;}}
      if(found) sh.getRange(found,1,1,row.length).setValues([row]); else sh.appendRow(row);
    });
    return out({ok:true,synced:visits.length,at:new Date().toISOString()});
  } catch(err) { return out({ok:false,error:String(err)}); }
}
function doGet(){return out({ok:true,service:'FieldLedger Sheets API'});}
function out(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}
