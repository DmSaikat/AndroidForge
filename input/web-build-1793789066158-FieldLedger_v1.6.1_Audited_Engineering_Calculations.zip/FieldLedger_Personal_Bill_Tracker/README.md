# FieldLedger - BD Technology Personal Bill Tracker

FieldLedger is a personal Android record book for field visits, advances, bill items, receipts and balances. It does not include office submission, approval or rejection workflows.

## Main features
- Editable visit details: factory/client, location, engineer/name, optional Employee ID, Designation and Department, Bill Date, Visit Date, manual Work Scope, advance and payment details.
- Multiple expenditure entries in one batch. Each line has an expense type (Rickshaw, CNG, Bike, Bus, Allowance or manual type), particulars and amount; edit or delete entries later.
- Delete a whole visit with a confirmation prompt.
- Receipt photo selection, preview and compression.
- Four-option fixed bottom navigation: Home, Activity, Create and Office Payment, plus the Measurement Tools tab.
- Non-zooming Android WebView with normal scrolling and clipped off-screen menu overflow.
- Individual visit, monthly, yearly and all-visit A4 Expenditure Bill exports.
- Print layout mirrors the user's BD Technology paper form, including signature lines.
- Local JSON backup export/import plus Google Sheets/Drive backup and restore.

## Build
Upload the project ZIP to your AndroidForge-compatible builder, select **Android (APK)** and **Debug**, then build. This archive is source code, not a compiled APK.

## Configure backup
Follow `SETUP_GOOGLE_SHEETS.md` and update `google-apps-script/Code.gs` with your Sheet ID, Drive folder ID and unique API key before deploying the Apps Script Web App.


## Version 1.5 update
- Bottom navigation now contains Home, Activity, Create and Office Payment. The unused Budget and Debts shortcuts were removed.
- Office Payment records additional office funds against a selected visit with date, method, reference and note; payments are included in visit balance calculations.
- Expenditure entries now have a type dropdown (Rickshaw, CNG, Bike, Bus, Allowance) and a Manual type option, alongside particulars and amount. The selected type is retained in reports.


## Version 1.6.1 update
- Added Measurement Tools: calculator, unit converter, electrical calculator and cable reference.
- Expanded unit conversion with imperial gallons, cubic inches, stone, kilogram-force and related engineering units.
- Corrected electrical calculator mode handling: input kW vs mechanical output kW, kW-to-kVA, mechanical HP-to-kW and three-phase transformer FLC now use distinct assumptions.
- Cable reference uses the published Bangladesh Power Division 15 Dec 2021 BYA copper 1-core concealed/surface values. NYY ratings are not guessed; use a matching manufacturer's datasheet.
- Removed automatic breaker-size suggestion because ampacity alone cannot establish protective-device selection.
- Voltage-drop result is explicitly an approximate resistive screening estimate, not a full AC impedance/code-compliance calculation.
- Monthly/yearly summaries show advance and expenditure totals only; they do not display a misleading net balance that omits returned cash and additional office payments.
