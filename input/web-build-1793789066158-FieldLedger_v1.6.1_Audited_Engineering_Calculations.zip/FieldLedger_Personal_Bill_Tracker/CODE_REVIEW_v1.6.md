# FieldLedger v1.6.1 — Code review findings

## Corrected
1. Electrical calculator previously validated power factor and efficiency for every mode, even when irrelevant, and treated all entered kW as motor output by dividing by efficiency. It now separates electrical input kW from mechanical output kW and applies efficiency only to mechanical-output current calculations.
2. Transformer full-load current is explicitly three-phase and uses kVA with line-to-line voltage. kW-to-kVA and mechanical HP-to-kW have separate assumptions.
3. Cable voltage default now switches to 230 V for single phase and 400 V for three phase.
4. Cable voltage drop is labelled a resistive approximation using copper resistivity at 20°C; it omits reactance, operating temperature, joints and correction factors. It no longer claims that this result proves BNBC compliance.
5. Removed the automatic breaker-size suggestion. The previous logic selected the first nominal rating above load current and below uncorrected ampacity, which is not enough to select an MCB/MCCB safely.
6. Cable table now retains only BYA copper 1-core C/S values published in the Bangladesh Power Division guideline dated 15 Dec 2021. NYY is intentionally not assigned a generic rating because core count, conductor material, installation condition and manufacturer construction matter.
7. Added warning for 1.0 mm² where the user may be considering a building final/sub-circuit: BNBC 2020 Part 8 specifies minimum 1.5 mm² for final/sub-circuits and light/fan point wiring. This warning does not replace application-specific engineering review.
8. Monthly/yearly summary previously computed net balance as advance minus expenditure while omitting returned cash and extra office payments. The misleading net balance was removed; reports remain advance/expenditure summaries.
9. Blank unused expense rows can now be left blank without validation failure.

## Verified references
- BNBC 2020 Part 8, Chapter 1: nominal supply 230 V single-phase and 400 V three-phase; 2.5% voltage-drop criterion; final/sub-circuit minimum conductor sizes; thermal and protective coordination requirements.
- Bangladesh Power Division guideline, circular dated 15 Dec 2021, Appendix table “Current Carrying Capacity of Copper”: BYA 1-core C/S values. The document identifies NYY as PVC-insulated/PVC-sheathed copper or aluminium cable and describes indoor/outdoor/underground/water applications; it does not justify one universal NYY ampacity for all configurations.

## Remaining limitations
- The BYA table is a residential-wiring reference. It is not a complete industrial cable-sizing database. Apply project-specific installation conditions and derating.
- No full IEC/BS cable-sizing engine, short-circuit withstand calculation, earth-fault loop calculation, protection coordination, motor starting study or VCB selection is implemented.
- The voltage-drop estimator is not a full AC calculation using cable R/X data and conductor operating temperature.
- No automated breaker recommendation is provided intentionally.
- Existing app-wide cloud sync remains best-effort while the app is active; this review did not convert it into a guaranteed Android background sync worker.
- Android APK build and device-level testing were not performed.
