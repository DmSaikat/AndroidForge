# FieldLedger v1.6.1 — code review and Measurement Tools revision

- Added and revised Measurement Tools.
- Corrected electrical calculator mode-specific formulas and input assumptions.
- Corrected default voltage when switching between single-phase (230 V) and three-phase (400 V) cable calculations.
- Removed unsafe automatic breaker nominal-rating suggestion. MCB/MCCB selection requires protective-device coordination and fault-level checks; VCB remains outside the LV calculator.
- Replaced ambiguous extra cable table columns with only the verified BYA copper 1-core concealed/surface values. NYY ampacity is not inferred from BYA or unrelated columns.
- Added BNBC final-circuit minimum-size warning for 1.0 mm².
- Clearly labelled voltage-drop estimate as resistive-only and non-certifying.
- Removed misleading monthly/yearly net balance calculation; those reports remain advance/expenditure summaries.
- Fixed blank unused expense-row handling.
- Expanded unit converter.

Validation performed: JavaScript syntax check, HTML ID uniqueness check, asset parity check, ZIP integrity check and targeted arithmetic tests. No Android APK build or physical-device test performed.
