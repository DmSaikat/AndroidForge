# FieldLedger — BD Technology Personal Bill Tracker

## Version 1.7.3 — Visible Google Drive backup and dark mode

FieldLedger remains a local-first personal record book. It does not require a FieldLedger login, cloud recovery code, Apps Script deployment, or a custom backend.

### Visible backup and restore

The Home screen now has a dedicated **Backup & appearance** panel, so the Google Drive actions do not require opening the navigation drawer. The same actions remain in the drawer.

- **Back up to Google Drive:** FieldLedger creates a complete JSON backup and opens the Android save screen. Choose Google Drive and save the file in a folder you can find again.
- **Restore from Google Drive:** FieldLedger opens the Android document picker. Choose the saved JSON backup.
- The same Google account must be available in the Android Google Drive app/provider to access that Drive file. This is Google Drive access, not a FieldLedger login.
- Backup is manual, not automatic. Save a new backup after important changes.
- The app records when a backup file was created, but it cannot independently verify that the selected destination was Google Drive.

### Restore modes

- **MERGE** adds visits from the backup. For matching visit IDs, it keeps the visit with the newer `updatedAt` timestamp. Visits already on the phone but absent from the backup are retained.
- **REPLACE** replaces the current local database with the selected backup. Use this only when you intend to replace the current records.
- Invalid files are rejected before the local database is changed.

### Existing data and upgrade

The Android application ID remains `com.fieldledger.app`, and the local database key remains `fieldledger.personal.v2`. Install this APK as an update over the existing FieldLedger app; do not uninstall the old version first. A normal in-place update preserves local app data.

The backup format remains compatible with FieldLedger v1.7.1 JSON exports. Receipt photos embedded as image data are included in the backup. Existing receipt references that are Google Drive file IDs remain references to those original Drive files; they are not downloaded and embedded by this manual backup feature. For those older references, keep access to the Google account that stores the receipt files.

#### Dark mode

- Toggle Light/Dark mode from the Home screen or navigation drawer.
- The selected theme is remembered locally and restored at app launch.
- Android status and navigation bars follow the selected theme.

## Existing features preserved

- Visit creation, editing and deletion.
- Expenditure entries including Transport, Rickshaw, CNG, Bike, Bus, Allowance and custom categories.
- Office payments, advances, cash returned and visit balances.
- Receipt images and individual bill exports.
- Monthly and yearly summary exports.
- Measurement Tools, calculator, unit converter and electrical calculation references.
- BD Technology branding and existing navigation.

### Build

Upload this project ZIP to AndroidForge, choose Android (APK), and build. This ZIP is source code, not a compiled APK.

### Limitations

- The app cannot back up automatically to Drive without a cloud integration.
- User must choose Google Drive in the Android save/open document picker.
- A file saved only on local storage does not protect against phone loss.
- Test one backup and restore before relying on it.

### Previous v1.7.1 cloud files

This version does not use the old Apps Script endpoint. It does not delete the old FieldLedger Drive vault, backup snapshots, or receipt folder. Keep those files in Drive until you have successfully created and tested a v1.7.3 manual backup. Legacy receipt IDs in visit records still point to those original Drive files.


## Version 1.7.5 additions
- Menu navigation preserves scroll position instead of jumping to the top.
- Employee Profile stores name, employee ID, designation, department and photo.
- New visits use profile details as defaults; bills use visit-specific values first, then profile defaults.
- Profile data is included in JSON backups.

## v1.9.1 — BOQ quantity and rate calculations
- Added BOQ quantity take-off register, PWD Appendix B/C load and fixture references, preliminary changeover/ECC helpers, four-zone electrical labour calculator, and custom unit-rate build-up.
- See `RELEASE_NOTES_v1.9.1.md` and the companion `FieldLedger_BOQ_Calculation_Guide_PWD_SoR2022.pdf` for details and source limitations.

## Version 1.9.2 — Full PWD SoR 2022 PDF search

- Offline search index covers all 1,041 extracted text pages of the supplied `Electrical_PWD.pdf`.
- BOQ search accepts item numbers, descriptions, equipment terms, ratings, cable types and common electrical notation variants.
- Results show item/unit, source PDF page and all four PWD regional rate columns where four numeric rates passed the extraction consistency check.
- OCR-ambiguous rows remain searchable as extracted page text but are not offered as automatically priced PWD items.
- Existing small transcribed PWD reference rows are retained as quick matches; all source rates still require comparison with the original PDF before tender use.
- The indexed source is PWD SoR 2022, not a current 2026 market-rate source.

### PDF extraction quality

The full text index includes 1,041 pages. Initial row extraction produced 891 item-row candidates; 294 had four regional prices parsed consistently enough to show as rate candidates (142 numeric reads without character substitution and 152 OCR-reconstructed candidates). None are independently certified: even unmodified OCR can misread numbers or column alignment. Reconstructed candidates are specially flagged. The remaining records are still searchable by page text, but rates must be verified manually against the original scanned table. The model-specific vehicle repair section is not interpreted as four regional rates.

Install/build: package this source through AndroidForge. The PDF index file `pwd_sor2022_data.js` is required by both the web and Android WebView copies.


## v1.9.3 PWD BOQ pricing safety update

- All OCR-extracted and OCR-reconstructed PWD rates from v1.9.2 are withheld from automatic BOQ pricing.
- Only 53 item rows manually transcribed and visually checked against original PWD PDF scan pages 47, 48, 155, 156, 165 and 343 are eligible for automatic price transfer.
- Other PDF matches remain searchable by item number, description, material, specification and source page, but have no auto-applied price.
- Raw OCR text from pages identified as PWD rate tables is suppressed in the result/page viewer.
- Material references include Copper (Cu), Aluminium (Al), BYA/BYM/BYFYE/NYY/HT-XLPE cables, cable current capacity reference, earthing/ECC, copper busbar and switchgear.
- See `PWD_PRICE_VERIFICATION_AUDIT_v1.9.3.md` for the enabled price allow-list.
